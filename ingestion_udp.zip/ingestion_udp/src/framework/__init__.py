"""
PDF Processing Framework for Databricks

A minimal framework focused on configuration management and utilities.

Features:
- YAML configuration management with validation
- File handling utilities
- Extensible architecture for future task development

Example usage:
    from framework.utils import ConfigManager
    
    config = ConfigManager("config/pipeline.yaml")
    globals_config = config.get("globals", {})
"""

__version__ = "1.0.0"

# Import utility classes
from .utils import ConfigManager, FileHandler, make_async_worker, process_batch_async, AsyncWorkerPool
from .acordis_client import AcordisApiClient
from .step_executor import StepExecutor, parse_xml_content

__all__ = [
    # Utilities
    "ConfigManager", 
    "FileHandler",
    "make_async_worker",
    "process_batch_async",
    "AsyncWorkerPool",
    
    # API Clients
    "AcordisApiClient",
    
    # Step Executors
    "StepExecutor",
    "parse_xml_content"
]


def get_framework_info() -> dict:
    """
    Get information about the framework and available components.
    
    Returns:
        Dictionary with framework information
    """
    return {
        "version": __version__,
        "utilities": [
            "ConfigManager",
            "FileHandler"
        ],
        "async_utilities": [
            "make_async_worker",
            "process_batch_async", 
            "AsyncWorkerPool"
        ],
        "api_clients": [
            "AcordisApiClient"
        ],
        "step_executors": [
            "StepExecutor",
            "parse_xml_content"
        ],
        "features": [
            "YAML configuration management with validation",
            "File handling utilities",
            "Environment variable substitution",
            "Dot notation configuration access",
            "Unified Acordis API client for document processing",
            "Reusable step executors for processing pipelines",
            "XML parsing with synthetic and production modes",
            "High-performance async workers for concurrent API processing",
            "Async worker pools for managing multiple endpoints",
            "Batch processing utilities with retry logic",
            "Synthetic and production API modes",
            "Extensible architecture for future development"
        ]
    }