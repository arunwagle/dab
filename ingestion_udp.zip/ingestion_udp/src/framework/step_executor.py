"""
Step Executor for document processing pipeline.

This module provides reusable step functions for various document processing tasks
including XML parsing, data extraction, and transformation operations.
"""

import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from typing import Dict, Any, Optional


class StepExecutor:
    """
    Step executor for document processing pipeline operations.
    
    Provides reusable functions for XML parsing, data extraction,
    and other processing steps that can be used across workflows.
    """
    
    def __init__(self, use_synthetic: bool = True, **kwargs):
        """
        Initialize the step executor.
        
        Args:
            use_synthetic: Whether to use synthetic mode for testing
            **kwargs: Additional configuration options
        """
        self.use_synthetic = use_synthetic
        self.config = kwargs
    
    def parse_xml_content(self, file_path: str, submission_id: str) -> Dict[str, Any]:
        """
        Simple XML parsing function - no class, no REST API, just file processing.
        
        Args:
            file_path: Path to XML file in volumes
            submission_id: Unique submission identifier
            
        Returns:
            Dictionary with parsing results including success status and parsed data
        """
        try:
            start_time = time.time()
            
            if self.use_synthetic:
                # SYNTHETIC MODE: Fast mock processing for testing scalability
                time.sleep(0.01)  # Minimal processing time
                
                parsed_data = {
                    "submission_id": submission_id,
                    "text_content": f"Mock extracted text from XML for {submission_id}",
                    "table_count": 2,
                    "page_count": 4,
                    "document_structure": {
                        "sections": ["header", "body", "footer"],
                        "metadata": {"format": "xml", "version": "1.0"}
                    },
                    "processing_timestamp": ""
                    # datetime.now(timezone.utc).astimezone()
                }
            else:
                # PRODUCTION MODE: Real XML parsing
                with open(file_path, 'r', encoding='utf-8') as file:
                    xml_content = file.read()
                
                # Parse XML and extract structured data
                root = ET.fromstring(xml_content)
                
                parsed_data = {
                    "submission_id": submission_id,
                    "text_content": self._extract_text_from_xml(root),
                    "table_count": len(root.findall(".//table")),
                    "page_count": len(root.findall(".//page")),
                    "document_structure": self._extract_structure_from_xml(root)
                }
            
            processing_time_ms = int((time.time() - start_time) * 1000)
            
            return {
                'success': True,
                'parsed_data': parsed_data,
                'processing_time_ms': processing_time_ms,
                'file_size_bytes': len(str(parsed_data)),
                'error': None
            }
            
        except Exception as e:
            processing_time_ms = int((time.time() - start_time) * 1000) if 'start_time' in locals() else 0
            return {
                'success': False,
                'parsed_data': None,
                'processing_time_ms': processing_time_ms,
                'file_size_bytes': 0,
                'error': str(e)
            }
    
    def _extract_text_from_xml(self, root: ET.Element) -> str:
        """Extract all text content from XML."""
        return " ".join([elem.text or "" for elem in root.iter() if elem.text and elem.text.strip()])
    
    def _extract_structure_from_xml(self, root: ET.Element) -> Dict[str, Any]:
        """Extract document structure from XML."""
        return {
            "root_tag": root.tag,
            "child_elements": [child.tag for child in root],
            "total_elements": len(list(root.iter()))
        }


# Convenience functions for backward compatibility
def parse_xml_content(file_path: str, submission_id: str, use_synthetic: bool = True) -> Dict[str, Any]:
    """
    Standalone function for XML parsing - backward compatibility.
    
    Args:
        file_path: Path to XML file in volumes
        submission_id: Unique submission identifier
        use_synthetic: Whether to use synthetic mode
        
    Returns:
        Dictionary with parsing results
    """
    executor = StepExecutor(use_synthetic=use_synthetic)
    return executor.parse_xml_content(file_path, submission_id)


def extract_text_from_xml(root: ET.Element) -> str:
    """Extract all text content from XML - backward compatibility."""
    executor = StepExecutor()
    return executor._extract_text_from_xml(root)


def extract_structure_from_xml(root: ET.Element) -> Dict[str, Any]:
    """Extract document structure from XML - backward compatibility."""
    executor = StepExecutor()
    return executor._extract_structure_from_xml(root)
