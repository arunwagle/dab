"""
Async utilities for high-performance concurrent processing.

This module provides utilities for creating async workers that can handle
concurrent API requests with proper retry logic, error handling, and
resource management.
"""

import asyncio
import aiohttp
from typing import Callable, Dict, List, Any, Optional


def make_async_worker(api_base: str, api_path: str, api_key: str, 
                     max_conc: int = 16, timeout_s: int = 60, retries: int = 3) -> Callable:
    """
    Create an async worker function for concurrent API processing.
    
    This function creates a high-performance async worker that can process multiple
    API requests concurrently with retry logic and proper error handling.
    
    Args:
        api_base: Base URL for the API
        api_path: Specific API endpoint path
        api_key: Authentication key for the API
        max_conc: Maximum concurrent requests (default: 16)
        timeout_s: Timeout in seconds for each request (default: 60)
        retries: Number of retry attempts (default: 3)
        
    Returns:
        Async function that can process a list of row dictionaries
        
    Example:
        worker = make_async_worker("https://api.example.com", "/process", "key123")
        results = await worker([{"submission_id": "1", "file_path": "/path/to/file"}])
    """
    async def run(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Process a list of rows concurrently using async HTTP requests.
        
        Args:
            rows: List of dictionaries containing submission data
            
        Returns:
            List of result dictionaries with success/error status
        """
        sem = asyncio.Semaphore(max_conc)
        timeout = aiohttp.ClientTimeout(total=timeout_s)
        headers = {"Authorization": f"Bearer {api_key}"}
        
        async with aiohttp.ClientSession(base_url=api_base, timeout=timeout, headers=headers) as session:
            async def process_single_row(r: Dict[str, Any]) -> Dict[str, Any]:
                """Process a single row with retry logic."""
                err = None
                for attempt in range(retries + 1):
                    try:
                        body = {"submission_id": r["submission_id"], "path": r["file_path"]}
                        request_headers = {"Idempotency-Key": r["submission_id"]}
                        
                        async with sem, session.post(api_path, json=body, headers=request_headers) as resp:
                            data = await resp.json(content_type=None)
                            
                            if 200 <= resp.status < 300 and (data or {}).get("success", True):
                                return {
                                    "ok": True, 
                                    "status": resp.status, 
                                    "payload": data, 
                                    "error": None
                                }
                            err = data
                    except Exception as e:
                        err = str(e)
                    
                    # Exponential backoff with jitter
                    await asyncio.sleep(min(30, 2**attempt) + 0.1 * attempt)
                
                return {
                    "ok": False, 
                    "status": None, 
                    "payload": None, 
                    "error": err
                }
            
            return [await process_single_row(r) for r in rows]
    
    return run


async def process_batch_async(rows: List[Dict[str, Any]], 
                            api_base: str, 
                            api_path: str, 
                            api_key: str,
                            max_conc: int = 16,
                            timeout_s: int = 60,
                            retries: int = 3) -> List[Dict[str, Any]]:
    """
    Convenience function for processing a batch of rows with async API calls.
    
    Args:
        rows: List of row dictionaries to process
        api_base: Base URL for the API
        api_path: API endpoint path
        api_key: Authentication key
        max_conc: Maximum concurrent requests
        timeout_s: Request timeout in seconds
        retries: Number of retry attempts
        
    Returns:
        List of result dictionaries
    """
    worker = make_async_worker(api_base, api_path, api_key, max_conc, timeout_s, retries)
    return await worker(rows)


class AsyncWorkerPool:
    """
    A pool of async workers for managing multiple concurrent API operations.
    
    This class provides a higher-level interface for managing async workers
    with different configurations for different API endpoints.
    """
    
    def __init__(self):
        """Initialize the async worker pool."""
        self.workers: Dict[str, Callable] = {}
    
    def register_worker(self, name: str, api_base: str, api_path: str, api_key: str,
                       max_conc: int = 16, timeout_s: int = 60, retries: int = 3) -> None:
        """
        Register a new async worker with the pool.
        
        Args:
            name: Unique name for the worker
            api_base: Base URL for the API
            api_path: API endpoint path
            api_key: Authentication key
            max_conc: Maximum concurrent requests
            timeout_s: Request timeout in seconds
            retries: Number of retry attempts
        """
        self.workers[name] = make_async_worker(api_base, api_path, api_key, max_conc, timeout_s, retries)
    
    async def process_with_worker(self, worker_name: str, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Process rows using a specific registered worker.
        
        Args:
            worker_name: Name of the registered worker
            rows: List of row dictionaries to process
            
        Returns:
            List of result dictionaries
            
        Raises:
            KeyError: If worker_name is not found in the pool
        """
        if worker_name not in self.workers:
            raise KeyError(f"Worker '{worker_name}' not found in pool")
        
        worker = self.workers[worker_name]
        return await worker(rows)
    
    def list_workers(self) -> List[str]:
        """
        List all registered worker names.
        
        Returns:
            List of worker names
        """
        return list(self.workers.keys())
