"""
File handling utilities for PDF processing framework.

This module provides utilities for file operations, path management,
and data serialization used throughout the PDF processing pipeline.
"""

import os
import pickle
import json
import shutil
from typing import Any, Dict, List, Optional, Union
from pathlib import Path


class FileHandler:
    """
    Utility class for file operations and data serialization.
    
    Provides methods for:
    - File and directory operations
    - Data serialization (pickle, JSON)
    - Path validation and normalization
    - Temporary file management
    """
    
    @staticmethod
    def ensure_directory(path: Union[str, Path]) -> str:
        """
        Create directory if it doesn't exist.
        
        Args:
            path: Directory path to create
            
        Returns:
            Absolute path of the created directory
        """
        abs_path = os.path.abspath(str(path))
        os.makedirs(abs_path, exist_ok=True)
        return abs_path
    
    @staticmethod
    def validate_file_exists(file_path: Union[str, Path]) -> str:
        """
        Validate that a file exists.
        
        Args:
            file_path: Path to validate
            
        Returns:
            Absolute path if file exists
            
        Raises:
            FileNotFoundError: If file doesn't exist
        """
        abs_path = os.path.abspath(str(file_path))
        if not os.path.exists(abs_path):
            raise FileNotFoundError(f"File not found: {abs_path}")
        if not os.path.isfile(abs_path):
            raise ValueError(f"Path is not a file: {abs_path}")
        return abs_path
    
    @staticmethod
    def validate_pdf_file(file_path: Union[str, Path]) -> str:
        """
        Validate that a file exists and is a PDF.
        
        Args:
            file_path: Path to validate
            
        Returns:
            Absolute path if valid PDF
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file is not a PDF
        """
        abs_path = FileHandler.validate_file_exists(file_path)
        if not abs_path.lower().endswith('.pdf'):
            raise ValueError(f"File must be a PDF: {abs_path}")
        return abs_path
    
    @staticmethod
    def save_pickle(data: Any, file_path: Union[str, Path]) -> str:
        """
        Save data using pickle serialization.
        
        Args:
            data: Data to serialize
            file_path: Path to save file
            
        Returns:
            Absolute path where data was saved
        """
        abs_path = os.path.abspath(str(file_path))
        FileHandler.ensure_directory(os.path.dirname(abs_path))
        
        with open(abs_path, 'wb') as f:
            pickle.dump(data, f)
        
        return abs_path
    
    @staticmethod
    def load_pickle(file_path: Union[str, Path]) -> Any:
        """
        Load data from pickle file.
        
        Args:
            file_path: Path to pickle file
            
        Returns:
            Deserialized data
            
        Raises:
            FileNotFoundError: If file doesn't exist
        """
        abs_path = FileHandler.validate_file_exists(file_path)
        
        with open(abs_path, 'rb') as f:
            return pickle.load(f)
    
    @staticmethod
    def save_json(data: Dict[str, Any], file_path: Union[str, Path], 
                  indent: int = 2) -> str:
        """
        Save data as JSON file.
        
        Args:
            data: Data to serialize (must be JSON-serializable)
            file_path: Path to save file
            indent: JSON indentation level
            
        Returns:
            Absolute path where data was saved
        """
        abs_path = os.path.abspath(str(file_path))
        FileHandler.ensure_directory(os.path.dirname(abs_path))
        
        with open(abs_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)
        
        return abs_path
    
    @staticmethod
    def load_json(file_path: Union[str, Path]) -> Dict[str, Any]:
        """
        Load data from JSON file.
        
        Args:
            file_path: Path to JSON file
            
        Returns:
            Parsed JSON data
            
        Raises:
            FileNotFoundError: If file doesn't exist
            json.JSONDecodeError: If file is not valid JSON
        """
        abs_path = FileHandler.validate_file_exists(file_path)
        
        with open(abs_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    @staticmethod
    def copy_file(src: Union[str, Path], dst: Union[str, Path]) -> str:
        """
        Copy file from source to destination.
        
        Args:
            src: Source file path
            dst: Destination file path
            
        Returns:
            Absolute path of destination file
        """
        src_path = FileHandler.validate_file_exists(src)
        dst_path = os.path.abspath(str(dst))
        
        FileHandler.ensure_directory(os.path.dirname(dst_path))
        shutil.copy2(src_path, dst_path)
        
        return dst_path
    
    @staticmethod
    def get_file_size(file_path: Union[str, Path]) -> int:
        """
        Get file size in bytes.
        
        Args:
            file_path: Path to file
            
        Returns:
            File size in bytes
        """
        abs_path = FileHandler.validate_file_exists(file_path)
        return os.path.getsize(abs_path)
    
    @staticmethod
    def get_file_extension(file_path: Union[str, Path]) -> str:
        """
        Get file extension (without dot).
        
        Args:
            file_path: Path to file
            
        Returns:
            File extension in lowercase
        """
        return Path(file_path).suffix.lower().lstrip('.')
    
    @staticmethod
    def list_files(directory: Union[str, Path], 
                   extension: Optional[str] = None,
                   recursive: bool = False) -> List[str]:
        """
        List files in directory with optional filtering.
        
        Args:
            directory: Directory to search
            extension: File extension to filter by (without dot)
            recursive: Whether to search recursively
            
        Returns:
            List of absolute file paths
        """
        dir_path = Path(directory)
        if not dir_path.exists():
            raise FileNotFoundError(f"Directory not found: {directory}")
        
        if recursive:
            pattern = "**/*"
        else:
            pattern = "*"
        
        files = []
        for file_path in dir_path.glob(pattern):
            if file_path.is_file():
                if extension is None or FileHandler.get_file_extension(file_path) == extension.lower():
                    files.append(str(file_path.absolute()))
        
        return sorted(files)
    
    @staticmethod
    def clean_directory(directory: Union[str, Path], 
                       keep_directory: bool = True) -> None:
        """
        Remove all contents of a directory.
        
        Args:
            directory: Directory to clean
            keep_directory: Whether to keep the directory itself
        """
        dir_path = Path(directory)
        if dir_path.exists():
            if keep_directory:
                for item in dir_path.iterdir():
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item)
            else:
                shutil.rmtree(dir_path)
    
    @staticmethod
    def get_unique_filename(base_path: Union[str, Path]) -> str:
        """
        Generate a unique filename by adding a counter if needed.
        
        Args:
            base_path: Base file path
            
        Returns:
            Unique file path
        """
        path = Path(base_path)
        counter = 1
        
        while path.exists():
            stem = path.stem
            suffix = path.suffix
            parent = path.parent
            
            new_name = f"{stem}_{counter}{suffix}"
            path = parent / new_name
            counter += 1
        
        return str(path.absolute())
