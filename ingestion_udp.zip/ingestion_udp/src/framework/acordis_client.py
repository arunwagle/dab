"""
Unified Acordis API Client for document processing operations.

This module provides a single client class that handles all Acordis API operations
including document submission, status checking, and result downloading.
"""

import requests
import time
import json
import hashlib
import os
import shutil
from typing import Dict, Optional


class AcordisApiClient:
    """
    Unified client for all Acordis API operations.
    
    Handles document submission, status checking, and result downloading
    with support for both synthetic (testing) and production modes.
    """
    
    def __init__(self, api_url: str, api_key: str, timeout: int = 300, use_synthetic: bool = True, **kwargs):
        """
        Initialize the Acordis API client.
        
        Args:
            api_url: Base URL for the Acordis API
            api_key: API key for authentication
            timeout: Request timeout in seconds
            use_synthetic: Whether to use synthetic mode for testing
            **kwargs: Additional configuration options
        """
        self.api_url = api_url.rstrip('/')
        self.api_key = api_key
        self.timeout = timeout
        self.use_synthetic = use_synthetic
        
        # Setup HTTP session with common headers
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "User-Agent": "Databricks-DocumentProcessor/1.0"
        })
        
        # Synthetic data configuration (configurable via kwargs)
        self.samples_path = kwargs.get('samples_path', "/Volumes/aira/document_processing_bronze/documents/samples/")
        self.processed_xml_path = kwargs.get('processed_xml_path', "/Volumes/aira/document_processing_bronze/documents/processed/xml/")
    
    def submit_document(self, file_path: str, document_id: str, priority: int = 1) -> dict:
        """
        Submit a document for processing.
        
        Args:
            file_path: Path to the document file
            document_id: Unique identifier for the document
            priority: Processing priority (1-10, higher is more urgent)
            
        Returns:
            Standardized response dictionary with success status and details
        """
        try:
            start_time = time.time()
            
            if self.use_synthetic:
                # SYNTHETIC MODE: Mock API response for testing
                time.sleep(0.1)  # Simulate processing time
                response_time_ms = int((time.time() - start_time) * 1000)
                
                # Generate realistic synthetic transaction ID
                hash_input = f"{document_id}{file_path}{time.time()}"
                transaction_id = f"txn_{hashlib.md5(hash_input.encode()).hexdigest()[:12]}"
                
                # Simulate successful response matching Acordis API structure
                synthetic_response = {
                    "transaction_id": transaction_id,
                    "status": "submitted",
                    "message": "File successfully submitted for processing",
                    "file_info": {
                        "name": file_path.split('/')[-1],
                        "size": "unknown",
                        "type": "pdf"
                    },
                    "processing_info": {
                        "estimated_completion": "2024-01-01T12:00:00Z",
                        "priority": priority
                    }
                }
                
                return {
                    'success': True,
                    'transaction_id': transaction_id,
                    'status': 'submitted',
                    'response_time_ms': response_time_ms,
                    'full_response': json.dumps(synthetic_response)
                }
            else:
                # PRODUCTION MODE: Real API call to Acordis
                # Read file content (assuming PDF)
                with open(file_path, 'rb') as file:
                    file_content = file.read()
                
                # Prepare multipart form data according to API specification
                files = {
                    'files': (file_path.split('/')[-1], file_content, 'application/pdf')
                }
                
                # Make actual API call to /api/v1/transaction endpoint
                response = self.session.post(
                    f"{self.api_url}/api/v1/transaction",
                    files=files,
                    timeout=self.timeout
                )
                
                response_time_ms = int((time.time() - start_time) * 1000)
                
                # Handle response based on Acordis API status codes: 200, 400, 401, 403, 422
                if response.status_code == 200:
                    # Successful submission
                    api_response = response.json()
                    return {
                        'success': True,
                        'transaction_id': api_response.get('transaction_id'),
                        'status': api_response.get('status', 'submitted'),
                        'response_time_ms': response_time_ms,
                        'full_response': api_response
                    }
                elif response.status_code == 400:
                    # Bad Request - invalid file format, missing required fields, etc.
                    error_msg = f"Bad Request (400): Invalid file or missing required fields"
                    try:
                        error_details = response.json()
                        error_msg += f" - {error_details}"
                    except:
                        error_msg += f" - {response.text}"
                    
                    return {
                        'success': False,
                        'error': error_msg,
                        'response_time_ms': response_time_ms,
                        'full_response': response.text
                    }
                elif response.status_code == 401:
                    # Unauthorized - invalid API key
                    return {
                        'success': False,
                        'error': "Unauthorized (401): Invalid API key or authentication failed",
                        'response_time_ms': response_time_ms,
                        'full_response': response.text
                    }
                elif response.status_code == 403:
                    # Forbidden - insufficient permissions
                    return {
                        'success': False,
                        'error': "Forbidden (403): Insufficient permissions for this operation",
                        'response_time_ms': response_time_ms,
                        'full_response': response.text
                    }
                elif response.status_code == 422:
                    # Unprocessable Entity - validation errors
                    error_msg = f"Validation Error (422): File failed validation checks"
                    try:
                        error_details = response.json()
                        error_msg += f" - {error_details}"
                    except:
                        error_msg += f" - {response.text}"
                    
                    return {
                        'success': False,
                        'error': error_msg,
                        'response_time_ms': response_time_ms,
                        'full_response': response.text
                    }
                else:
                    # Other unexpected status codes
                    return {
                        'success': False,
                        'error': f"Unexpected API error {response.status_code}: {response.text}",
                        'response_time_ms': response_time_ms,
                        'full_response': response.text
                    }
                    
        except Exception as e:
            return {
                'success': False,
                'error': f"Document submission error: {str(e)}",
                'response_time_ms': int((time.time() - start_time) * 1000) if 'start_time' in locals() else 0
            }
    
    def check_status(self, transaction_id: str) -> Dict:
        """
        Check processing status for a transaction.
        
        Args:
            transaction_id: Transaction ID to check status for
            
        Returns:
            Standardized response dictionary with status information
        """
        try:
            if self.use_synthetic:
                # SYNTHETIC MODE: Always return completed status immediately
                return {
                    'success': True,
                    'data': {
                        'transaction_id': transaction_id,
                        'status': 'processed',  # Changed to match Acordis API spec
                        'progress': 100,
                        'completion_time': '2024-01-01T12:00:00Z',
                        'result_type': 'xml',
                        # Available output formats
                        'available_formats': ['xml', 'zip'],
                        'file_size': 15420,  # Approximate size of XML file
                        'processing_summary': {
                            'pages_processed': 3,
                            'text_extracted': True,
                            'tables_found': 2,
                            'images_found': 1
                        }
                    }
                }
            else:
                # PRODUCTION MODE: Real API call to /api/v1/transaction/status
                response = self.session.get(
                    f"{self.api_url}/api/v1/transaction/status",
                    params={"transactionId": transaction_id},
                    timeout=30
                )
                
                if response.status_code == 200:
                    return {
                        'success': True,
                        'data': response.json()
                    }
                else:
                    return {
                        'success': False,
                        'error': f"Status check failed: {response.status_code}"
                    }
                    
        except Exception as e:
            return {
                'success': False,
                'error': f"Status check error: {str(e)}"
            }
    
    def download_result(self, transaction_id: str, format: str = "xml") -> Dict:
        """
        Download processed document result.
        
        Args:
            transaction_id: Transaction ID for the processed document
            format: Output format ('xml' or 'zip')
            
        Returns:
            Standardized response dictionary with download content or error
        """
        try:
            if self.use_synthetic:
                # SYNTHETIC MODE: Copy sample XML file to processed folder
                try:
                    # Find any XML file in samples directory
                    sample_files = [f for f in os.listdir(self.samples_path) if f.endswith('.xml')]
                    if not sample_files:
                        return {
                            'success': False,
                            'error': f"No XML files found in samples directory: {self.samples_path}"
                        }
                    
                    # Use the first XML file found
                    sample_file = sample_files[0]
                    source_path = os.path.join(self.samples_path, sample_file)
                    
                    # Generate output filename based on transaction ID
                    output_filename = f"{transaction_id}.xml"
                    
                    # Ensure processed/xml directory exists
                    os.makedirs(self.processed_xml_path, exist_ok=True)
                    
                    # Copy file to processed directory
                    destination_path = os.path.join(self.processed_xml_path, output_filename)
                    # shutil.copy2(source_path, destination_path)
                    
                    # Read the copied file for content return
                    with open(destination_path, 'r', encoding='utf-8') as f:
                        xml_content = f.read()
                    
                    return {
                        'success': True,
                        'content': xml_content.encode('utf-8'),
                        'content_type': 'application/xml',
                        'filename': output_filename,
                        'source': 'synthetic',
                        'original_file': sample_file,
                        'destination_path': destination_path,
                        'format': format
                    }
                    
                except FileNotFoundError:
                    return {
                        'success': False,
                        'error': f"Samples directory not found: {self.samples_path}"
                    }
                except Exception as e:
                    return {
                        'success': False,
                        'error': f"Error copying sample XML file: {str(e)}"
                    }
            else:
                # PRODUCTION MODE: Real download from /api/v1/transaction/output
                response = self.session.get(
                    f"{self.api_url}/api/v1/transaction/output",
                    params={
                        "transactionId": transaction_id,
                        "format": format
                    },
                    timeout=300
                )
                
                if response.status_code == 200:
                    # Determine filename based on format
                    file_extension = "xml" if format == "xml" else "zip"
                    filename = f"{transaction_id}.{file_extension}"
                    
                    return {
                        'success': True,
                        'content': response.content,
                        'content_type': response.headers.get('content-type', 'application/octet-stream'),
                        'filename': filename,
                        'source': 'api',
                        'format': format
                    }
                else:
                    return {
                        'success': False,
                        'error': f"Download failed: {response.status_code}"
                    }
                    
        except Exception as e:
            return {
                'success': False,
                'error': f"Download error: {str(e)}"
            }
