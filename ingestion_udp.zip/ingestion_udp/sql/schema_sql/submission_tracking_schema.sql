-- ================================================================
-- Document Processing: Submission Tracking Schema Creation
-- ================================================================
-- This script creates the necessary schemas and tables for the
-- document submission tracking system.
-- 
-- Run this script manually in Databricks SQL Editor before 
-- executing the document processing workflows.
-- ================================================================

-- ================================================================
-- SCHEMA CREATION
-- ================================================================


-- Create bronze processing schema  
CREATE SCHEMA IF NOT EXISTS aira.document_processing_bronze
COMMENT 'Bronze layer schema for raw document processing data';

-- Create silver processing schema
CREATE SCHEMA IF NOT EXISTS aira.document_processing_silver  
COMMENT 'Silver layer schema for cleaned and transformed document data';

-- Create gold processing schema
CREATE SCHEMA IF NOT EXISTS aira.document_processing_gold
COMMENT 'Gold layer schema for business-ready document insights';

-- Create volumes
CREATE VOLUME IF NOT EXISTS aira.document_processing_bronze.documents;
CREATE VOLUME IF NOT EXISTS aira.document_processing_bronze.spark;

