# Document Processing Pipeline

A comprehensive, modular framework for processing PDF documents with support for text extraction, table detection, image extraction, and document analysis. Built for Databricks environments with Delta Live Tables (DLT) and Autoloader integration.

## Features

- 🔧 **Modular Framework**: Task-based pipeline with pluggable components
- 📄 **Complete PDF Processing**: Text, tables, images, and OCR extraction
- 🔗 **Document Analysis**: Build document structure graphs and classification
- ⚡ **Databricks Native**: DLT pipelines with Autoloader for streaming processing
- 🌊 **Real-time Processing**: Automatic processing as documents arrive
- ⚙️ **YAML Configuration**: Flexible pipeline configuration
- 📊 **Monitoring**: Built-in metrics and performance tracking

## Project Structure

```
udp-ai-project/
├── src/framework/                              # Modular processing framework
│   ├── base/                                  # Core framework classes
│   ├── tasks/                                 # Processing task implementations
│   ├── utils/                                 # Utility modules
│   └── integrations/                          # Databricks integrations
├── notebooks/data_engineering/document_processing/
│   ├── dlt_bronze_ingestion.py               # Bronze - Document ingestion
│   ├── dlt_silver_text_processing.py         # Silver - Text extraction
│   ├── dlt_silver_table_processing.py        # Silver - Table extraction
│   ├── dlt_silver_image_processing.py        # Silver - Image extraction
│   ├── dlt_gold_document_analysis.py         # Gold - Document analysis

│   └── job_post_processing_cleanup.py        # Cleanup & reporting
├── resources/data_engineering/document_processing/
│   ├── pipelines/                            # DLT pipeline configurations
│   └── jobs/                                 # Job orchestration configs
├── config/                                   # Framework configurations
└── databricks.yml                           # Asset bundle configuration
```

## Architecture

The pipeline follows a medallion architecture with three layers:

```
📄 PDF Documents (Autoloader) 
    ↓
🥉 BRONZE LAYER
├── Raw document ingestion & validation
├── Processing queue management
└── Error tracking
    ↓
🥈 SILVER LAYER (Parallel Processing)
├── Text Processing (Framework: TextParserTask)
├── Table Extraction (Framework: TableExtractorTask)  
└── Image Extraction (Framework: ImageExtractorTask)
    ↓
🥇 GOLD LAYER
├── Document analysis (Framework: GraphBuilderTask)
├── Document classification & insights
└── Performance analytics
```

## Workflow Orchestration

The document processing pipeline includes a comprehensive workflow job that automatically triggers each DLT pipeline in sequence:

### Workflow Features
- **Automated Pipeline Sequencing**: Triggers Bronze → Silver → Gold pipelines in order
- **Error Handling & Retries**: Up to 2 retries per pipeline with configurable delays
- **Conditional Execution**: Can force full refresh or incremental processing
- **Comprehensive Monitoring**: Real-time progress tracking and completion notifications
- **Manual Control**: Trigger individual pipelines or full workflow as needed

### Workflow Execution Order
1. **🔍 Workflow Validation** - Environment and prerequisite checks
2. **🥉 Bronze Pipeline** - Document ingestion with Autoloader (40 min timeout)
3. **🥈 Silver Pipeline** - Parallel text, table, and image processing (80 min timeout)
4. **🥇 Gold Pipeline** - Document analysis and classification (60 min timeout)
5. **🧹 Post-processing** - Cleanup and summary generation (20 min timeout)
6. **📧 Completion** - Notifications and monitoring dashboard updates (5 min timeout)

## Quick Deployment

### Prerequisites

- Databricks workspace with DLT enabled
- Unity Catalog configured
- Volume storage for documents and checkpoints

### Setup Volumes

```sql
-- Create catalog and volumes
CREATE CATALOG IF NOT EXISTS document_processing_dev;
CREATE SCHEMA IF NOT EXISTS document_processing_dev.volumes;
CREATE VOLUME IF NOT EXISTS document_processing_dev.volumes.landing;
CREATE VOLUME IF NOT EXISTS document_processing_dev.volumes.checkpoints;
```

### Deploy with Asset Bundles

```bash
# Install Databricks CLI
pip install databricks-cli

# Set environment variables
export DATABRICKS_HOST="https://your-workspace.cloud.databricks.com"
export DATABRICKS_TOKEN="your-access-token"

# Deploy pipeline
cd udp-ai-project
databricks bundle validate
databricks bundle deploy --target development
```

### Manual Deployment

If not using Asset Bundles:

1. **Upload notebooks** to workspace under `data_engineering/document_processing/`
2. **Create DLT pipelines** using the configurations in `resources/`
3. **Create job orchestrator** using the job configuration
4. **Configure volumes** and permissions

## Usage

### 1. Upload Documents

```python
# Upload PDF files to landing zone
dbutils.fs.cp("file:/local/path/document.pdf", 
              "/Volumes/document_processing_dev/volumes/landing/pdfs/document.pdf")
```

### 2. Trigger Processing

#### Full Workflow Execution
```python
# Option 1: Trigger complete workflow via Jobs API
dbutils.jobs.run_now(job_id="document_processing_workflow_dev")

# Option 2: Use manual trigger notebook
dbutils.notebook.run("notebooks/data_engineering/document_processing/job_manual_trigger.py", 
                     timeout_seconds=300,
                     arguments={"catalog": "document_processing_dev",
                               "environment": "development",
                               "force_full_refresh": "false"})
```

#### Individual Pipeline Execution
```python
# Trigger individual pipelines if needed
pipeline_id = "document_processing_bronze_dev"
w.pipelines.start_update(pipeline_id=pipeline_id)

# Or use the manual trigger notebook for individual stages
%run "./job_manual_trigger"
trigger_individual_pipeline("bronze")  # or "silver", "gold"
```

#### Scheduled Execution
```python
# The workflow can be scheduled (currently paused by default)
# Enable in databricks.yml or Jobs UI:
# schedule:
#   quartz_cron_expression: "0 0 2 * * ?"  # Daily at 2 AM
#   pause_status: "UNPAUSED"
```

### 3. Monitor Progress

#### Workflow Execution Monitoring
```sql
-- Check recent workflow executions
SELECT 
    run_id,
    execution_status,
    execution_timestamp,
    total_documents,
    successful_ingestions,
    failed_ingestions
FROM document_processing_dev.gold.document_pipeline_execution_history
ORDER BY execution_timestamp DESC LIMIT 10;

-- Check processing status by stage
SELECT 
    processing_status,
    COUNT(*) as document_count
FROM document_processing_dev.bronze.document_processing_queue_bronze
GROUP BY processing_status;
```

#### Performance Analytics
```sql
-- View processing performance metrics
SELECT 
    window_start,
    documents_processed,
    text_success_rate,
    table_success_rate,
    image_success_rate,
    overall_success_rate
FROM document_processing_dev.gold.document_processing_performance_analytics_gold
ORDER BY window_start DESC LIMIT 10;

-- Monitor real-time workflow progress
SELECT 
    metric_timestamp,
    metric_type,
    metric_value,
    environment
FROM document_processing_dev.gold.document_processing_monitoring
WHERE DATE(metric_timestamp) = CURRENT_DATE()
ORDER BY metric_timestamp DESC;
```

### 4. Query Results

```sql
-- Get document classifications
SELECT 
    document_name,
    document_classification,
    processing_quality_score,
    total_pages,
    total_words,
    total_tables,
    total_images
FROM document_processing_dev.gold.document_classification_gold
ORDER BY processing_quality_score DESC;

-- View insights by document type
SELECT 
    document_classification,
    document_count,
    avg_processing_quality,
    avg_pages,
    avg_tables,
    avg_images
FROM document_processing_dev.gold.document_insights_gold
ORDER BY document_count DESC;
```

## Configuration

### Pipeline Configuration Example

```yaml
# config/document_processing_pipeline.yaml
pipeline:
  - task: "TextParserTask"
    params:
      preserve_formatting: true
      extract_metadata: true
      
  - task: "TableExtractorTask"
    params:
      include_table_metadata: true
      table_settings:
        vertical_strategy: "lines_strict"
        
  - task: "ImageExtractorTask"
    params:
      min_image_size:
        width: 100
        height: 100
        
  - task: "GraphBuilderTask"
    params:
      graph_type: "directed"
      include_content: false
```

### Environment Configuration

```yaml
# databricks.yml
environments:
  development:
    variables:
      catalog: "document_processing_dev"
      notification_email: "dev-team@company.com"
      
  production:
    variables:
      catalog: "document_processing_prod"
      notification_email: "prod-alerts@company.com"
```

## Data Tables

### Bronze Layer
- `document_files_bronze` - Raw document metadata
- `document_processing_queue_bronze` - Processing queue
- `document_ingestion_metrics_bronze` - Ingestion metrics

### Silver Layer
- `document_text_processing_silver` - Text extraction results
- `document_table_processing_silver` - Table extraction results  
- `document_image_processing_silver` - Image extraction results
- `document_*_silver` - Individual content tables (pages, tables, images)

### Gold Layer
- `document_processing_summary_gold` - Complete processing summary
- `document_classification_gold` - Document classification results
- `document_processing_performance_analytics_gold` - Performance metrics
- `document_insights_gold` - Corpus-level insights

## Framework Components

The modular framework includes:

- **TextParserTask**: Extract structured text with metadata
- **TableExtractorTask**: Detect and extract tables with analysis
- **ImageExtractorTask**: Extract images with positioning data
- **GraphBuilderTask**: Build document structure graphs
- **ConfigManager**: YAML configuration management
- **SparkUtils**: Spark/streaming integration utilities
- **DLTIntegration**: Delta Live Tables support
- **AutoloaderIntegration**: Streaming document processing

## Monitoring

Pipeline execution generates comprehensive metrics:

- Processing throughput and latency
- Success rates by processing type
- Document classification distribution
- Error analysis and categorization
- Resource utilization metrics

## Support

For issues or questions:
1. Check the error logs in `*_errors_silver` tables
2. Review pipeline execution history in `document_pipeline_execution_history`
3. Monitor processing metrics for performance insights

## License

This project is licensed under the MIT License.
