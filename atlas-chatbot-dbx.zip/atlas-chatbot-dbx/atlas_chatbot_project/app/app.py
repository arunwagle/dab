### TODO: Move these variables to config file!!
catalog = "imdx_test"
schema = "ops_work"
volume_prefix = "databricks_genai_poc/on_demand_volume/"

import io
import logging
import os
import time
import secrets
import streamlit as st
from model_serving_utils import (
    endpoint_supports_feedback, 
    query_endpoint, 
    query_endpoint_stream, 
    _get_endpoint_task_type,
)
from collections import OrderedDict
from messages import UserMessage, AssistantResponse, render_message
from databricks.sdk import WorkspaceClient
import databricks.sdk as dbx
# from databricks.sdk.service import files

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

SERVING_ENDPOINT = os.getenv('SERVING_ENDPOINT')
assert SERVING_ENDPOINT, \
    ("Unable to determine serving endpoint to use for chatbot app. If developing locally, "
     "set the SERVING_ENDPOINT environment variable to the name of your serving endpoint. If "
     "deploying to a Databricks app, include a serving endpoint resource named "
     "'serving_endpoint' with CAN_QUERY permissions, as described in "
     "https://docs.databricks.com/aws/en/generative-ai/agent-framework/chat-app#deploy-the-databricks-app")

ENDPOINT_SUPPORTS_FEEDBACK = endpoint_supports_feedback(SERVING_ENDPOINT)

def build_rerun_button():
    _, button_location = st.columns([6,1])
    with button_location:
        clicked = st.button("NEW SESSION", use_container_width=True, key="stop_button")
    if clicked and True:
        st.session_state.clear()
        st.rerun()
    return clicked

def build_sidebar():
    st_sidebar = st.sidebar
    # --- Streamlit UI Components ---
    st_sidebar.title(r"Upload File\(s\) to Unity Catalog Volume")

    # Multiple file uploader widget
    # https://docs.streamlit.io/develop/api-reference/widgets/st.file_uploader
    uploaded_files = st_sidebar.file_uploader(
        r"Choose file\(s\) to upload", 
        accept_multiple_files=True,
        disabled=st.session_state.uploader_disabled,
        help="Select one or more files to upload."
    )

    ### TODO: Get these values from configuration
    volume_base_path = f"{catalog}/{schema}/{volume_prefix}"

    # --- File Processing and Upload Logic ---
    if st_sidebar.button(r"**Upload & Process**", 
                         disabled=st.session_state.save_to_uc_button_disabled) and uploaded_files:
        try:
            # First, disable the file uploader widget and the save to UC button
            # st.session_state.uploader_disabled = True
            # st.session_state.save_to_uc_button_disabled = True

            # Initialize the Databricks WorkspaceClient.
            # Assumes authentication is handled by the environment (e.g., on a Databricks cluster).
            w = WorkspaceClient()
            
            # Use a progress bar to show upload status
            upload_progress = st_sidebar.progress(0)

            # Create a placeholder to display file names as they are uploaded
            upload_status_placeholder = st_sidebar.empty()
            
            # Process each uploaded file
            num_files = len(uploaded_files)
            for i, uploaded_file in enumerate(uploaded_files):
                file_name = uploaded_file.name
                
                # Construct the full destination path in the volume
                dest_path = f"/Volumes/{volume_base_path}{st.session_state.session_id}/{file_name}"
                
                # Read file contents into bytes
                file_bytes = uploaded_file.read()
                
                # Create a file_info object for the Databricks SDK
                file_info = dbx.service.files.FileInfo(
                    file_size=len(file_bytes),
                    path=dest_path
                )
                
                # Use the Databricks SDK to copy the file bytes to the volume.
                # The SDK's `upload` method handles overwriting automatically.
                w.files.upload(
                    file_path=dest_path,
                    contents=io.BytesIO(file_bytes)
                )
                
                upload_status_placeholder.write(f"Successfully uploaded {file_name} ({i + 1} / {num_files})")
                
                # Update the progress bar
                upload_progress.progress((i + 1) / num_files)

            # st_sidebar.balloons()
            upload_status_placeholder.success("All files have been saved to the volume.")
            

        except Exception as e:
            st_sidebar.error(f"An error occurred: {e}")

        with st.spinner("Processing uploaded files..."):
            processing_status_placeholder = st_sidebar.empty()

            job_id = "22822922431800"   # TODO: Get this value from configuration
            # Trigger run of upload processing job
            try:
                run_response = w.jobs.run_now(job_id=job_id, job_parameters={"session_id": st.session_state.session_id})
                run_id = run_response.response.run_id
            except Exception as e:
                st_sidebar.exception(f"Error triggering processing job: {e}")

            # Block until the `vs_index` task of the processing job completes
            while True:
                run_details = w.jobs.get_run(run_id=run_id)
                vs_index_task = [t for t in run_details.tasks if t.task_key == "vs_index"][0]
                vs_index_task_status = vs_index_task.status
                if vs_index_task_status.state.name != "TERMINATED":
                    time.sleep(1)
                else:
                    if vs_index_task_status.termination_details.code.name == "SUCCESS":
                        processing_status_placeholder.success(r"**Processing completed successfully!** You may now query the agent using the uploaded information.")
                    else:
                        processing_status_placeholder.error(f"Processing failed: {vs_index_task_status.termination_details.message}")
                    break


# --- Init state ---
if "history" not in st.session_state:
    st.session_state.history = []

if "session_id" not in st.session_state:
    # st.session_state.session_id = None
    st.session_state.session_id = secrets.token_hex()

if "uploader_disabled" not in st.session_state:
    st.session_state.uploader_disabled = False

if "save_to_uc_button_disabled" not in st.session_state:
    st.session_state.save_to_uc_button_disabled = False


st.title("Atlas")
st.write(f"A Voya chatbot")
st.write(f"Endpoint name: `{SERVING_ENDPOINT}`")

build_sidebar()
build_rerun_button()

# --- Render chat history ---
for i, element in enumerate(st.session_state.history):
    element.render(i)

def query_endpoint_and_render(task_type, input_messages):
    """Handle streaming response based on task type."""
    return query_chat_agent_endpoint_and_render(input_messages)


def query_chat_agent_endpoint_and_render(input_messages):
    """Handle ChatAgent streaming format."""
    from mlflow.types.agent import ChatAgentChunk
    
    with st.chat_message("assistant"):
        response_area = st.empty()
        response_area.markdown("Thinking...")
        
        message_buffers = OrderedDict()
        request_id = None
     
        messages, request_id = query_endpoint(
            endpoint_name=SERVING_ENDPOINT,
            messages=input_messages,
            return_traces=ENDPOINT_SUPPORTS_FEEDBACK
        )

        with response_area.container():
            for message in messages:
                render_message(message)
        return AssistantResponse(messages=messages, request_id=request_id)



def build_state():

    if 'model' not in st.session_state.keys():
        st.session_state['model'] = None

    # Update history to use new Message format instead of ChatAgentMessage
    if 'history' not in st.session_state.keys():
        st.session_state['history'] = []

    if 'provider' not in st.session_state.keys():
        st.session_state['provider'] = None

    if 'providers' not in st.session_state.keys():
        st.session_state['providers'] = get_available_tools()

    if ('tools' not in st.session_state.keys()) or ('selection' not in st.session_state.keys()):
        tools = list(itertools.chain.from_iterable(st.session_state['providers'].values()))
        st.session_state['tools'] = dict(map(lambda x: [x.tool_id, x], tools))
        st.session_state['selection'] = dict(map(lambda x: [x.tool_id, False], tools))


# --- Chat input (must run BEFORE rendering messages) ---
prompt = st.chat_input("Ask a question")
if prompt:
    # Add sesison ID to prompt
    prompt = f"Session_ID: {st.session_state.session_id}. User: {prompt}"

    # Get the task type for this endpoint
    task_type = _get_endpoint_task_type(SERVING_ENDPOINT)
    
    # Add user message to chat history
    user_msg = UserMessage(content=prompt)
    st.session_state.history.append(user_msg)
    user_msg.render(len(st.session_state.history) - 1)

    # Convert history to standard chat message format for the query methods
    input_messages = [msg for elem in st.session_state.history for msg in elem.to_input_messages()]
    
    # Handle the response using the appropriate handler
    assistant_response = query_endpoint_and_render(task_type, input_messages)
    
    # Add assistant response to history
    st.session_state.history.append(assistant_response)