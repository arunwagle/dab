# Model Validation
To enable model validation as part of scheduled databricks workflow, please refer to [atlas_chatbot_project/resources/README.md](../resources/README.md)
