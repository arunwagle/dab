# Databricks notebook source
# MAGIC %md
# MAGIC # Mapping Table
# MAGIC
# MAGIC Use `Serverless` compute

# COMMAND ----------

dbutils.widgets.text("catalog_name", "imdx_test")
dbutils.widgets.text("schema_name", "rag_poc")
dbutils.widgets.text("schema_name_opswork", "ops_work")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")
schema_opswork = dbutils.widgets.get("schema_name_opswork")

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.eqr_mapping_data_cleaned as
WITH base AS (
  SELECT name, ticker, sedol, entity_id, country, TO_DATE(`Period (Formatted)`, 'dd-MMM-yyyy') AS period
  FROM `{catalog}`.`{schema}`.eqr_mapping_data_2022_2025
),
ranked AS (
  SELECT *,
    ROW_NUMBER() OVER (PARTITION BY name, ticker, sedol, entity_id 
    ORDER BY period DESC
  ) AS rn
  FROM base
)
SELECT name, ticker, sedol, entity_id, country, period
FROM ranked
WHERE rn = 1
;
"""
)

# COMMAND ----------

spark.sql(
f"""
select * from `{catalog}`.`{schema}`.eqr_mapping_data_cleaned limit 5;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter for only SP500 companies

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.eqr_mapping_data_sp500_only as
with joined as (
  select a.*, b.COMPANYNAME as name_in_sp500 
  from `{catalog}`.`{schema}`.eqr_mapping_data_cleaned a
  left join (
    select distinct COMPANYNAME, SEDOL
    from `{catalog}`.`{schema_opswork}`.sp500_ecall_2022_2025
  ) b
  on a.SEDOL = b.SEDOL
)
select name_in_sp500 as name, ticker, sedol, entity_id, country, period
from joined
where name_in_sp500 is not null
"""
)