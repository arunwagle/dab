# Databricks notebook source
# MAGIC %md
# MAGIC # Sell-Side Research Data
# MAGIC
# MAGIC Use `Serverless` compute

# COMMAND ----------

dbutils.widgets.text("catalog_name", "imdx_test")
dbutils.widgets.text("schema_name", "rag_poc")
dbutils.widgets.text("schema_name_opswork", "ops_work")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")
schema_opswork = dbutils.widgets.get("schema_name_opswork")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

research_report_path = f"/Volumes/{catalog}/{schema_opswork}/databricks_genai_poc/MS_sell_side_reports/"
row_tag  = "Research"

sample_df = (
    spark.read.format("xml")
    .option("rowTag", row_tag)
    .load(research_report_path)
)

xml_schema = sample_df.schema

# COMMAND ----------

df_xml = (
    # read XML files from a UC volume location
    spark.read.format("xml")
    .schema(xml_schema)
    .option("rowTag", row_tag)
    .load(research_report_path)
    #.withColumn("_file_path", input_file_name())
    .withColumn("_file_path", col("_metadata.file_path"))
    .withColumn("_file_name", regexp_extract("_file_path", r'[^/]+$', 0))
    
    # write to UC as a Delta table
    .write.format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"`{catalog}`.`{schema}`.sellside_research_bronze")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.sellside_research_silver as
with base as (
  SELECT
    concat(Product.Content.Title, '\n\n', Product.Content.Abstract) as research_summary,
    issuer.IssuerName.NameValue AS issuer_name,
    sid.TradingExchange AS trading_exchange,
    sid._idValue as sedol,
    _createDateTime,
    _researchID,
    _file_name
  FROM `{catalog}`.`{schema}`.sellside_research_bronze AS a
  LATERAL VIEW OUTER explode(a.product.context.issuerdetails.Issuer) issuer_lv AS issuer 
  LATERAL VIEW OUTER explode(issuer.SecurityDetails.Security.SecurityID) sid_lv AS sid
  WHERE sid._idType = 'SEDOL'
  and _language = 'eng'
)
select _researchID as research_id,
  _file_name as file_name,
  date(_createDateTime) as create_date,
  base.sedol,
  b.ticker,
  issuer_name,
  trading_exchange,
  research_summary
from base
left join `{catalog}`.`{schema}`.eqr_mapping_data_cleaned b
on base.sedol = b.sedol
;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.sellside_research_gold as
select 
  uuid() as doc_id,
  research_id,
  file_name,
  create_date,
  year(create_date) as create_year,
  ticker, 
  sedol, 
  issuer_name,
  research_summary
from `{catalog}`.`{schema}`.sellside_research_silver
;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Review

# COMMAND ----------

spark.sql(
f"""
select *
from `{catalog}`.`{schema}`.sellside_research_gold
where array_contains(ticker, 'MSFT')
;
"""
)

# COMMAND ----------

