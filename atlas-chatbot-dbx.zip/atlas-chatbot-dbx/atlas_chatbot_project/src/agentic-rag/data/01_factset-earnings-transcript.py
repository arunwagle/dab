# Databricks notebook source
# MAGIC %md
# MAGIC # FactSet Earnings Call Transcript (DESCOPED; DO NOT USE)
# MAGIC
# MAGIC Use a multi-worker CPU cluster, since chunking requires a bit of compute.

# COMMAND ----------

dbutils.widgets.text("catalog_name", "imdx_test")
dbutils.widgets.text("schema_name", "rag_poc")
dbutils.widgets.text("schema_name_opswork", "ops_work")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")
schema_opswork = dbutils.widgets.get("schema_name_opswork")

# COMMAND ----------

# DBTITLE 1,View raw data
spark.sql(
f"""
select *
from `{catalog}`.`{schema_opswork}`.e_call_processed_transcript_05222025
limit 5
"""
)

# COMMAND ----------

# DBTITLE 1,Bronze: deduplicate transcript data
spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.earnings_call_transcripts_bronze as
SELECT *
FROM
  (
    SELECT
      *,
      ROW_NUMBER() OVER (
        PARTITION BY ENTITY_ID,
        COMPANY_NAME,
        CALL_NAME,
        CALL_ID
        ORDER BY
          VERSION_ID DESC
      ) AS RN
    FROM `{catalog}`.`{schema_opswork}`.e_call_processed_transcript_05222025
  ) T
WHERE
  RN = 1
  and DATE BETWEEN "2022-05-01" and "2025-05-01" --- POC SCOPE
;
"""
)

# COMMAND ----------

# DBTITLE 1,Silver: join with speaker metadata
spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.earnings_call_transcripts_silver as
WITH parsed AS (
  SELECT
    *,
    from_json(FILT_ALL, 'array<string>') AS TRANSCRIPT,
    from_json(SECTION_IDENTIFIER, 'array<string>') AS SECTION,
    from_json(SPEAKER_IDENTIFIER, 'array<string>') AS SPEAKER
  FROM `{catalog}`.`{schema}`.earnings_call_transcripts_bronze
),
zipped AS (
  SELECT *, arrays_zip(TRANSCRIPT, SECTION, SPEAKER) AS triplets
  FROM parsed
), 
cleaned as (
  SELECT ENTITY_ID, CALL_ID, VERSION_ID, DATE, CALL_NAME, COMPANY_NAME,
    concat_ws(
      '\n',
      transform(
        filter(triplets, t -> t.SECTION = 'MD'),
        t -> t.SPEAKER || ': ' || t.TRANSCRIPT
      )
    ) AS MD_TRANSCRIPT,
    concat_ws(
      '\n',
      transform(
        filter(triplets, t -> t.SECTION = 'QA'),
        t -> t.SPEAKER || ': ' || t.TRANSCRIPT
      )
    ) AS QA_TRANSCRIPT
  FROM
    zipped
    where COMPANY_NAME is not null and COMPANY_NAME != ""
)
select uuid() as id,
    entity.*, 
    sector.* except (sector.FACTSET_ENTITY_ID),
    industry_map.* except (industry_map.FACTSET_INDUSTRY_CODE, industry_map.FACTSET_SECTOR_CODE),
    sector_map.* except (sector_map.FACTSET_SECTOR_CODE),
    cleaned.* except (cleaned.ENTITY_ID)
from cleaned 
left join `{catalog}`.`{schema_opswork}`.sym_entity entity
on cleaned.ENTITY_ID = entity.FACTSET_ENTITY_ID
left join `{catalog}`.`{schema_opswork}`.sym_entity_sector sector
on cleaned.ENTITY_ID = sector.FACTSET_ENTITY_ID
left join `{catalog}`.`{schema_opswork}`.factset_industry_map industry_map
on sector.INDUSTRY_CODE = industry_map.FACTSET_INDUSTRY_CODE
left join `{catalog}`.`{schema_opswork}`.factset_sector_map sector_map
on sector.SECTOR_CODE = sector_map.FACTSET_SECTOR_CODE
;
"""
)

# COMMAND ----------

# DBTITLE 1,Gold: setup splitter
from langchain_text_splitters import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    chunk_size=5000,
    chunk_overlap=1000,
    length_function=len,
)

# COMMAND ----------

# DBTITLE 1,Gold: setup UDF
from pyspark.sql import functions as F, types as T
import pandas as pd

return_schema = T.ArrayType(
    T.StructType(
        [
            T.StructField("chunk_id", T.IntegerType()),
            T.StructField("chunk", T.StringType())
        ]
    )
)

@F.pandas_udf(returnType=return_schema)
def split_to_structs(text_col: pd.Series) -> pd.Series:
    return text_col.apply(
        lambda x: [{"chunk_id": i, "chunk": c}
                   for i, c in enumerate(splitter.split_text(x or ""))]
    )

# COMMAND ----------

# DBTITLE 1,Gold: chunk documents
transcript_chunked = (
    spark.read.table("`{catalog}`.`{schema}`.earnings_call_transcripts_silver")
    .repartition("id")
    .withColumn("chunks_struct", split_to_structs("MD_TRANSCRIPT"))
    .select("*", F.explode("chunks_struct").alias("cs"))
    .selectExpr("* except(cs)", "cs.chunk_id", "cs.chunk")
)

# COMMAND ----------

# DBTITLE 1,Gold: write to UC
transcript_gold = (
    transcript_chunked.withColumn(
        "doc_id", F.concat(F.col("id"), F.lit("-"), F.col("chunk_id"))
    )
    .withColumnRenamed("chunk", "doc_chunk")
    .select(
        "doc_id",
        "factset_entity_id",
        "iso_country",
        "factset_industry_desc",
        "factset_sector_desc",
        "date",
        "call_name",
        "company_name",
        "doc_chunk"
    )
    .write.mode("overwrite")
    .saveAsTable("`{catalog}`.`{schema}`.earnings_call_transcripts_gold")
)

# COMMAND ----------

spark.sql(
f"""
select * from `{catalog}`.`{schema}`.earnings_call_transcripts_gold limit 5;
"""
)