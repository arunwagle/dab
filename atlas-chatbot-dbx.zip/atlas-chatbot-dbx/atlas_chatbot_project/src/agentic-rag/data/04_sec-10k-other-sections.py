# Databricks notebook source
# MAGIC %md
# MAGIC # SEC 10K Other Sections
# MAGIC
# MAGIC Use a multi-worker CPU cluster, since chunking requires a bit of compute.

# COMMAND ----------

dbutils.widgets.text("catalog_name", "imdx_test")
dbutils.widgets.text("schema_name", "rag_poc")
dbutils.widgets.text("schema_name_opswork", "ops_work")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")
schema_opswork = dbutils.widgets.get("schema_name_opswork")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Raw

# COMMAND ----------

spark.sql(
f"""
select *
from `{catalog}`.`{schema}`.SEC_10K_STANDARDIZED_TEXT_SAMPLES
where ticker = 'mmm'
and FISCAL_PERIOD_END BETWEEN "2022-05-01" and "2025-05-01"
limit 10
;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.sec_10k_other_sections_bronze as
select 
  CIK, TICKER, FORM_TYPE, NAME, FISCAL_PERIOD_END, `"10K_LINK"` as 10K_LINK, FILING_DATE, BATCH_LOAD_DT as LOAD_DATE,
  "ITEM1A_RISK" as SECTION_NAME, 
  ITEM1A_RISK as SECTION_TEXT, 
  ITEM1A_LENGTH as SECTION_LENGTH
from `{catalog}`.`{schema_opswork}`.SEC_10K_STANDARDIZED_TEXT_SAMPLES
union
select 
  CIK, TICKER, FORM_TYPE, NAME, FISCAL_PERIOD_END, `"10K_LINK"` as 10K_LINK, FILING_DATE, BATCH_LOAD_DT as LOAD_DATE,
  "ITEM1B_UNRESOLVED" as SECTION_NAME, 
  ITEM1B_UNRESOLVED as SECTION_TEXT, 
  ITEM1B_LENGTH as SECTION_LENGTH
from `{catalog}`.`{schema_opswork}`.SEC_10K_STANDARDIZED_TEXT_SAMPLES
union
select 
  CIK, TICKER, FORM_TYPE, NAME, FISCAL_PERIOD_END, `"10K_LINK"` as 10K_LINK, FILING_DATE, BATCH_LOAD_DT as LOAD_DATE,
  "ITEM3_LEGAL" as SECTION_NAME, 
  ITEM3_LEGAL as SECTION_TEXT, 
  ITEM3_LENGTH as SECTION_LENGTH
from `{catalog}`.`{schema_opswork}`.SEC_10K_STANDARDIZED_TEXT_SAMPLES
union
select 
  CIK, TICKER, FORM_TYPE, NAME, FISCAL_PERIOD_END, `"10K_LINK"` as 10K_LINK, FILING_DATE, BATCH_LOAD_DT as LOAD_DATE,
  "ITEM4_MINE" as SECTION_NAME, 
  ITEM4_MINE as SECTION_TEXT, 
  ITEM4_LENGTH as SECTION_LENGTH
from `{catalog}`.`{schema_opswork}`.SEC_10K_STANDARDIZED_TEXT_SAMPLES
union
select 
  CIK, TICKER, FORM_TYPE, NAME, FISCAL_PERIOD_END, `"10K_LINK"` as 10K_LINK, FILING_DATE, BATCH_LOAD_DT as LOAD_DATE,
  "ITEM7_MDA" as SECTION_NAME, 
  ITEM7_MDA as SECTION_TEXT, 
  ITEM7_LENGTH as SECTION_LENGTH
from `{catalog}`.`{schema_opswork}`.SEC_10K_STANDARDIZED_TEXT_SAMPLES
union
select 
  CIK, TICKER, FORM_TYPE, NAME, FISCAL_PERIOD_END, `"10K_LINK"` as 10K_LINK, FILING_DATE, BATCH_LOAD_DT as LOAD_DATE,
  "ITEM7A_QUANTITATIVE" as SECTION_NAME, 
  ITEM7A_QUANTITATIVE as SECTION_TEXT, 
  ITEM7A_LENGTH as SECTION_LENGTH
from `{catalog}`.`{schema_opswork}`.SEC_10K_STANDARDIZED_TEXT_SAMPLES
union
select 
  CIK, TICKER, FORM_TYPE, NAME, FISCAL_PERIOD_END, `"10K_LINK"` as 10K_LINK, FILING_DATE, BATCH_LOAD_DT as LOAD_DATE,
  "ITEM8_QUANTITATIVE" as SECTION_NAME, 
  ITEM8_QUANTITATIVE as SECTION_TEXT, 
  ITEM8_LENGTH as SECTION_LENGTH
from `{catalog}`.`{schema_opswork}`.SEC_10K_STANDARDIZED_TEXT_SAMPLES
;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.sec_10k_other_sections_silver as
select uuid() as id,
  CIK,
  upper(a.TICKER) as TICKER,
  b.sedol as SEDOL,
  FORM_TYPE,
  a.NAME,
  date(FISCAL_PERIOD_END) as FISCAL_PERIOD_END,
  year(FISCAL_PERIOD_END) as FISCAL_PERIOD_YEAR,
  date(FILING_DATE) as FILING_DATE,
  date(LOAD_DATE) as LOAD_DATE,
  SECTION_NAME,
  SECTION_TEXT,
  SECTION_LENGTH,
  10K_LINK
from `{catalog}`.`{schema}`.sec_10k_other_sections_bronze a
left join (
  select name, ticker, sedol
  from `{catalog}`.`{schema}`.eqr_mapping_data_cleaned
) b on upper(a.TICKER) = b.ticker
where a.TICKER is not null
  and FISCAL_PERIOD_END BETWEEN "2022-05-01" and "2025-05-01"
  and SECTION_LENGTH > 0
  and SECTION_TEXT != ' '
;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold

# COMMAND ----------

from langchain_text_splitters import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    chunk_size=5000,
    chunk_overlap=500,
    length_function=len,
    separators=[". "],
    keep_separator="end"
)

# COMMAND ----------

from pyspark.sql import functions as F, types as T
import pandas as pd

return_schema = T.ArrayType(
    T.StructType(
        [
            T.StructField("chunk_id", T.IntegerType()),
            T.StructField("chunk", T.StringType())
        ]
    )
)

@F.pandas_udf(returnType=return_schema)
def split_to_structs(text_col: pd.Series) -> pd.Series:
    return text_col.apply(
        lambda x: [{"chunk_id": i, "chunk": c}
                   for i, c in enumerate(splitter.split_text(x or ""))]
    )

# COMMAND ----------

sec10k_chunked = (
    spark.read.table("`{catalog}`.`{schema}`.sec_10k_other_sections_silver")
    .repartition("id")
    .filter(F.col("sedol").isNotNull())
    .withColumn("chunks_struct", split_to_structs("SECTION_TEXT"))
    .select("*", F.explode("chunks_struct").alias("cs"))
    .selectExpr("* except(cs)", "cs.chunk_id", "cs.chunk")
)

# COMMAND ----------

# DBTITLE 1,Silver: write to UC
sec10k_gold = (
    sec10k_chunked.withColumn(
        "doc_id", F.concat(F.col("id"), F.lit("-"), F.col("chunk_id"))
    )
    .withColumnRenamed("chunk", "doc_chunk")
    .select(
        "doc_id",
        "ticker",
        "sedol",
        "form_type",
        "name",
        "fiscal_period_end",
        "fiscal_period_year",
        "section_name",
        "doc_chunk",
        "10k_link",
    )
    .write.mode("overwrite")
    .saveAsTable("`{catalog}`.`{schema}`.sec_10k_other_sections_gold")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Review

# COMMAND ----------

# DBTITLE 1,Review gold data
spark.sql(
f"""
select *
from `{catalog}`.`{schema}`.sec_10k_other_sections_gold
where ticker = 'NVDA'
and fiscal_period_year = '2025'
;
"""
)

# COMMAND ----------



# COMMAND ----------

