# Databricks notebook source
# MAGIC %md
# MAGIC # S&P 500 Earnings Transcript

# COMMAND ----------

dbutils.widgets.text("catalog_name", "imdx_test")
dbutils.widgets.text("schema_name", "rag_poc")
dbutils.widgets.text("schema_name_opswork", "ops_work")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")
schema_opswork = dbutils.widgets.get("schema_name_opswork")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Raw

# COMMAND ----------

spark.sql(
f"""
select *, length(componenttext)
from `{catalog}`.`{schema_opswork}`.sp500_ecall_2022_2025
where 0=0
and periodenddate is not null
order by length(componenttext) desc
limit 10
"""
)

# COMMAND ----------

spark.sql(
f"""
select distinct(transcriptcomponenttypename)
from `{catalog}`.`{schema_opswork}`.sp500_ecall_2022_2025;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.sp500_earnings_call_bronze as
select concat(string(keydevid), '-', string(transcriptid)) as call_id, 
  componentorder as order_n, 
  fiscalyear as fiscal_year, 
  fiscalquarter as fiscal_quarter, 
  date(periodenddate) as fiscal_period_end, 
  companyname as name, 
  b.ticker, 
  a.sedol, 
  transcriptcomponenttypename as transcript_type,
  case when transcriptcomponenttypename in ('Presenter Speech', 'Presentation Operator Message') 
    then 'Management Discussion' else 'Question & Answer' end as transcript_category,
  speakertypename as speaker_type, 
  transcriptpersonname as transcript_person_name, 
  componenttext as original_text,
  CASE WHEN transcriptcomponenttypename = 'Question' THEN 1 ELSE 0 END AS is_question,
  concat(
    "#", string(componentorder), '.\n',
    "Speaker: ", transcriptpersonname, "\n", 
    "Group: ", speakertypename, "\n",
    "Transcript: ", componenttext, "\n"
  ) as transcript_text,
  length(COMPONENTTEXT) as char_count
from `{catalog}`.`{schema_opswork}`.sp500_ecall_2022_2025 a
left join (
  select name, ticker, sedol
  from `{catalog}`.`{schema}`.eqr_mapping_data_cleaned
) b on a.SEDOL = b.sedol
where 0=0
and periodenddate is not null
order by keydevid, transcriptid, componentorder
;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.sp500_earnings_call_md_silver as
with base as (
  select distinct call_id, order_n, fiscal_year, fiscal_quarter, fiscal_period_end,
    name, ticker, sedol, transcript_type, transcript_category, speaker_type, 
    transcript_person_name, is_question, transcript_text, char_count
  from `{catalog}`.`{schema}`.sp500_earnings_call_bronze
  where transcript_category = 'Management Discussion'
  order by call_id, order_n
)
select call_id, 
  order_n as segment_id, 
  fiscal_year, fiscal_quarter, fiscal_period_end, name, ticker, sedol, 
  transcript_text as segmented_text,
  char_count
from base
where 0=0
and speaker_type != 'Operator'
order by call_id, order_n
;
"""
)

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.sp500_earnings_call_qa_silver as
with base as (
  select distinct call_id, order_n, fiscal_year, fiscal_quarter, fiscal_period_end,
    name, ticker, sedol, transcript_type, transcript_category, speaker_type, 
    transcript_person_name, is_question, transcript_text, char_count
  from `{catalog}`.`{schema}`.sp500_earnings_call_bronze
  where 0=0
  and transcript_category = 'Question & Answer'
  and speaker_type != 'Operator'
  order by call_id, order_n
)
, segmented as (
  select *,
    sum(is_question) over (
      partition by call_id
      order by order_n
      rows between unbounded preceding and current row
    ) as segment_id
  from base
)
select call_id, segment_id, fiscal_year, fiscal_quarter, fiscal_period_end, name, ticker, sedol, 
  CONCAT_WS(
    '\n', 
    COLLECT_LIST(transcript_text)
  ) as segmented_text,
  sum(char_count) as char_count
from segmented
group by 1, 2, 3, 4, 5, 6, 7, 8
order by call_id, segment_id
;
"""
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold

# COMMAND ----------

spark.sql(
f"""
create or replace table `{catalog}`.`{schema}`.sp500_earnings_call_gold as
with base as (
  select * from `{catalog}`.`{schema}`.sp500_earnings_call_md_silver
  union 
  select * from `{catalog}`.`{schema}`.sp500_earnings_call_qa_silver
)
select uuid() as doc_id,
  concat(call_id, '-', (segment_id)) as call_id,
  fiscal_year, fiscal_quarter, fiscal_period_end, name, ticker, sedol, 
  segmented_text as doc_chunk
from base
;
"""
)