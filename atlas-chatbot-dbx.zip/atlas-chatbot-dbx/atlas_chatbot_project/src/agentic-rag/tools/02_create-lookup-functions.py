# Databricks notebook source
# MAGIC %md
# MAGIC # Create Unity Catalog Functions
# MAGIC
# MAGIC These functions can be used by agens. For this POC, a validator agent uses these function to lookup and make sure users are only asking questions about real existing companies. For ths POC, we are only using companies in the S&P 500 index.

# COMMAND ----------

dbutils.widgets.text("catalog_name", "imdx_test")
dbutils.widgets.text("schema_name", "rag_poc")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")

# COMMAND ----------

#catalog = "imdx_test"
#schema = "rag_poc"

# COMMAND ----------

display(
    spark.sql(
        f"""
        -- look at table this function runs on
        select *
        from `{catalog}`.`{schema}`.`eqr_mapping_data_sp500_only` 
        limit 10;
        """
    )
)

# COMMAND ----------

spark.sql(
    f"""
    CREATE OR REPLACE FUNCTION `{catalog}`.`{schema}`.`lookup_company_info_by_name_test`(
        input_name STRING COMMENT 'Name of the company whose info to look up'
    )
    RETURNS STRING
    COMMENT "Returns metadata about a particular company, given the company's name, including its TICKER and SEDOL. The
    company TICKER or SEDOL can be used for other queries."
    RETURN SELECT CONCAT(
        'Company Name: ', name, ', ',
        'Company Ticker: ', ticker, ', ',
        'Company Sedol: ', sedol
    )
    FROM `{catalog}`.`{schema}`.`eqr_mapping_data_sp500_only` -- changed to sp500 only
    WHERE lower(name) like lower(concat('%', input_name, '%'))
    LIMIT 1;          
    """
)

# COMMAND ----------

spark.sql(
    f"""
    CREATE OR REPLACE FUNCTION `{catalog}`.`{schema}`.`lookup_company_info_by_ticker_test`(
        input_ticker STRING COMMENT 'Ticker of the company whose info to look up'
    )
    RETURNS STRING
    COMMENT "Returns metadata about a particular company, given the company's name, including its TICKER and SEDOL. The
    company TICKER or SEDOL can be used for other queries."
    RETURN SELECT CONCAT(
        'Company Name: ', name, ', ',
        'Company Ticker: ', ticker, ', ',
        'Company Sedol: ', sedol
    )
    FROM `{catalog}`.`{schema}`.`eqr_mapping_data_sp500_only` -- changed to sp500 only
    WHERE lower(ticker) like lower(concat('%', input_ticker, '%'))
    LIMIT 1;          
    """
)