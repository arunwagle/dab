# Databricks notebook source
# MAGIC %md
# MAGIC # Create Base Tables for Vector Search Index Creation
# MAGIC
# MAGIC * User `Serverless` compute
# MAGIC * For the 4 datasets we ingested and cleaned previously, here we make sure they all have the same schema which makes downstream agent tool calling simpler to implement.

# COMMAND ----------

dbutils.widgets.text("catalog_name", "imdx_test")
dbutils.widgets.text("schema_name", "rag_poc")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")

# COMMAND ----------

#catalog = "imdx_test"
#schema = "rag_poc"

# COMMAND ----------

spark.sql(f"""
    create or replace table {catalog}.{schema}.vs_sellside_research as
    select doc_id, 
        file_name as doc_link, 
        create_date as date, 
        string(create_year) as year, 
        ticker, 
        sedol, 
        issuer_name as name, 
        research_summary as doc_chunk
    from {catalog}.{schema}.sellside_research_gold;
""")


# COMMAND ----------

spark.sql(f"""
    create or replace table {catalog}.{schema}.vs_sec_10k_business as
    select doc_id, 10k_link as doc_link, fiscal_period_end as date, string(fiscal_period_year) as year, 
    ticker, sedol, name, 
    concat(
        "Excerpt from ", name, 
        " ", string(fiscal_period_year), 
        " ", form_type,
        " Section ", section_name, 
        ":\n", doc_chunk
    ) as doc_chunk
    from {catalog}.{schema}.sec_10k_business_section_gold;
""")


# COMMAND ----------

spark.sql(f"""
    create or replace table {catalog}.{schema}.vs_sec_10k_others as
    select doc_id, 10k_link as doc_link, fiscal_period_end as date, string(fiscal_period_year) as year, 
    ticker, sedol, name, 
    concat(
        "Excerpt from ", name, 
        " ", string(fiscal_period_year), 
        " ", form_type,
        " Section ", section_name, 
        ":\n", doc_chunk
    ) as doc_chunk
    from {catalog}.{schema}.sec_10k_other_sections_gold;
""")

# COMMAND ----------

spark.sql(f"""
    create or replace table {catalog}.{schema}.vs_sp500_earnings_call as
    select doc_id, 
    concat(
        string(fiscal_year),
        " Quarter #", string(fiscal_quarter),
        " ", name,
        " Earnings Call Transcript"
    ) as doc_link,
    fiscal_period_end as date,
    string(fiscal_year) as year,
    ticker, sedol, name,
    doc_chunk
    from {catalog}.{schema}.sp500_earnings_call_gold;
""")
