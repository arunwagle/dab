# Databricks notebook source
# MAGIC %pip install databricks-vectorsearch --quiet
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("catalog_name", "imdx_test")
dbutils.widgets.text("schema_name", "rag_poc")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient

vs_client = VectorSearchClient()
vs_index = vs_client.get_index(
    endpoint_name="voya_rag_poc", # specify the endpoint the indexes live on
    index_name=f"`{catalog}`.`{schema}`.vs_sec_10k_business_index" # specify the index you are searching on
)
vs_index.similarity_search(
    query_text="solar energy advantages", # phrase you ares searching for
    columns=["doc_id", "ticker", "name", "doc_chunk"], # columns to return on your search
    num_results=3, # number of results to return; max of 10,000 for ANN search, 200 for hybrid search
    query_type="ann", # "ann" or "hybrid"; ANN is search based on similarity score, while Hybrid includes keyword search in addition to ANN
)