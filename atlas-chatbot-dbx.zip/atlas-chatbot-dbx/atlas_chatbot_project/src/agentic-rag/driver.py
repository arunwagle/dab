# Databricks notebook source
# MAGIC %md
# MAGIC # Driver Notebook
# MAGIC
# MAGIC In this notebook:
# MAGIC * Init agent based on the `agent` notebook
# MAGIC * Test output
# MAGIC * Run evaluation

# COMMAND ----------

import os

# COMMAND ----------

print(os.getcwd())

# COMMAND ----------

python_model_test=os.path.join(os.getcwd(), "agent")

# COMMAND ----------

print(python_model_test)

# COMMAND ----------

# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %pip install -q -U -r requirements.txt
# MAGIC %pip install uv --quiet

# COMMAND ----------

# MAGIC %pip uninstall -y databricks-connect pyspark pyspark-connect
# MAGIC %pip install databricks-connect>=15.1.0
# MAGIC dbutils.library.restartPython()
# MAGIC
# MAGIC #TODO: this si a temperary solution due to this error message:
# MAGIC # Exception: pyspark and databricks-connect cannot be installed at the same time. To use databricks-connect, uninstall databricks-connect & pyspark by running 'pip uninstall -y databricks-connect pyspark pyspark-connect' followed by a re-installation of databricks-connect

# COMMAND ----------

# MAGIC %md
# MAGIC # Load Configs

# COMMAND ----------

import mlflow

configs = mlflow.models.ModelConfig(development_config="./configs.yaml")

databricks_configs = configs.get("databricks_configs")
tool_configs = configs.get("tool_configs")
agent_configs = configs.get("agent_configs")

# catalog = databricks_configs.get("catalog")
# schema = databricks_configs.get("schema")

dbutils.widgets.text("catalog_name", "")
dbutils.widgets.text("schema_name", "")
catalog = dbutils.widgets.get("catalog_name")
schema = dbutils.widgets.get("schema_name")

mlflow_experiment_name = databricks_configs.get("mlflow_experiment_name")
model_name = databricks_configs['agent_name']
print(catalog, schema, model_name)

vs_indexes = tool_configs.get("retrievers").get("indexes")
uc_tools = tool_configs.get("uc_tools")
llm_endpoint = agent_configs.get("validator_agent").get("llm").get("llm_endpoint_name")
embedding_model_endpoint = tool_configs.get("retrievers").get("embedding_model")

# COMMAND ----------

import os
from dbruntime.databricks_repl_context import get_context
from mlflow.utils.databricks_utils import get_databricks_host_creds

TOKEN = get_databricks_host_creds("databricks").token # TODO: replace with service principal for prod

os.environ['DATABRICKS_TOKEN'] = TOKEN
os.environ['DATABRICKS_URL'] = get_context().apiUrl

# COMMAND ----------

import mlflow
from dbruntime.databricks_repl_context import get_context

experiment_fqdn = f"/Workspace/LLM POC/agentic-rag/{mlflow_experiment_name}"

# Check if the experiment exists
experiment = mlflow.get_experiment_by_name(experiment_fqdn)

if experiment:
    experiment_id = experiment.experiment_id
    # Create the experiment if it does not exist
else:
    experiment_id = mlflow.create_experiment(experiment_fqdn)

mlflow.set_experiment(experiment_fqdn)

# COMMAND ----------

#dbutils.widgets.get("catalog_name")
#dbutils.widgets.get("schema_name")

# COMMAND ----------

# MAGIC %md
# MAGIC # Run Agent Code

# COMMAND ----------

# MAGIC %run ./agent

# COMMAND ----------

# MAGIC %md
# MAGIC # Test Agent

# COMMAND ----------

test_questions = [
    # "What are some of the macroeconomic and geopolitical factors that could affect FedEx's operations and business levels?",

    # "Summarize potential long-term competitive threats, technological disruptions, policy changes, or secular shifts that could threaten FedEx.",

    "Provide a clear and concise breakdown of Saleforces’s long-term growth drivers and total addressable market (TAM) evolution. \nAssume the audience is a sector-savvy investment analyst with no prior knowledge of the company. \n\nStructure: \n- Business model & key revenue streams \n- TAM segmentation: current and forward view (by geography, indication, tech platform, etc.) \n- Growth drivers: clinical, commercial, regulatory, competitive \n- Key assumptions: pricing, adoption, market expansion \n- Risks and sensitivities: downside scenarios or TAM disruption",

    # "What is Saleforces’s long-term growth drivers and total addressable market (TAM) evolution",

    # "what is tesla's robotaxi TAM?"

    # "why did Amazon stock rise after Q1 2024 earnings?",

    # "How do Constellation Energy's 2025 nuclear capacity plans compare to Duke Energy's?"

    # "what's the latest on URBN?",

    # "How much nuclear capacity does CEG have?",

    # "What are the key risks for Netflix in 2023?",

    # "How is Apple's revenue expected to grow next quarter?",

]

example_input = {
    "messages": [
        {
            "role": "user",
            "content": test_questions[0],
        }
    ]
}

example_input

# COMMAND ----------

response = AGENT.predict(example_input)
print(response.messages[0].content)

# COMMAND ----------

# MAGIC %md
# MAGIC # Run Evaluation

# COMMAND ----------

# import pandas as pd
# from mlflow.genai import datasets, evaluate, scorers

# EVAL_DATASET_NAME = f"{catalog}.{schema}.agent_eval_dataset"
# dataset = datasets.get_dataset(EVAL_DATASET_NAME)
# evals_df = dataset.to_df()

# display(evals_df)

# COMMAND ----------

# def predict_fn(messages):
#     return AGENT.predict(messages=[ChatAgentMessage(**message) for message in messages])

# COMMAND ----------

# evals = mlflow.genai.evaluate(
#     data=evals_df, 
#     predict_fn=predict_fn, 
#     scorers=scorers.get_all_scorers()
# )

# COMMAND ----------

# MAGIC %md
# MAGIC # Log & Register Agent as Model

# COMMAND ----------

#model_name = "DBA_deployed_research_agent_test"

# COMMAND ----------

registered_model_name = f"{catalog}.{schema}.{model_name}"

# COMMAND ----------

# DBTITLE 1,log model
import mlflow
from mlflow.models.resources import (
    DatabricksVectorSearchIndex,
    DatabricksServingEndpoint,
    DatabricksSQLWarehouse,
    DatabricksFunction,
    DatabricksTable,
    DatabricksUCConnection,
)

print(catalog, schema, model_name)

print (f"{catalog}.{schema}.{vs_indexes.get('sec_10k_business').get('index_name')}")
print (f"{catalog}.{schema}.{vs_indexes.get('sec_10k_others').get('index_name')}")
print (f"{catalog}.{schema}.{vs_indexes.get('sellside_research').get('index_name')}")
print (f"{catalog}.{schema}.{vs_indexes.get('sp500_earanings_call').get('index_name')}")
print (f"{catalog}.{schema}.{uc_tools.get('validator').get('by_name')}")      
print (f"{catalog}.{schema}.{uc_tools.get('validator').get('by_ticker')}")

with mlflow.start_run():
    logged_chain_info = mlflow.pyfunc.log_model(
        name=model_name,  # Required by MLflow
        registered_model_name=registered_model_name,
        python_model=os.path.join(os.getcwd(), "agent"),
        model_config=os.path.join(os.getcwd(), "configs.yaml"),
        input_example=example_input,
        resources=[
            DatabricksVectorSearchIndex(
                index_name=f"{catalog}.{schema}.{vs_indexes.get('sec_10k_business').get('index_name')}"
            ),
            DatabricksVectorSearchIndex(
                index_name=f"{catalog}.{schema}.{vs_indexes.get('sec_10k_others').get('index_name')}"
            ),
            DatabricksVectorSearchIndex(
                index_name=f"{catalog}.{schema}.{vs_indexes.get('sellside_research').get('index_name')}"
            ),
            DatabricksVectorSearchIndex(
                index_name=f"{catalog}.{schema}.{vs_indexes.get('sp500_earanings_call').get('index_name')}"
            ),
            DatabricksServingEndpoint(endpoint_name=llm_endpoint),
            DatabricksServingEndpoint(endpoint_name=embedding_model_endpoint),
            DatabricksFunction(
                function_name=f"{catalog}.{schema}.{uc_tools.get('validator').get('by_name')}"
            ),
            DatabricksFunction(
                function_name=f"{catalog}.{schema}.{uc_tools.get('validator').get('by_ticker')}"
            )
        ],
        pip_requirements=["-r requirements.txt"],
    )

# COMMAND ----------

# pre-deployment validation test
mlflow.models.predict(
    model_uri=f"runs:/{logged_chain_info.run_id}/{model_name}",
    input_data=example_input,
    env_manager="uv",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Register Agent as Model

# COMMAND ----------

# DBTITLE 1,register model
# register the model to UC
mlflow.set_registry_uri("databricks-uc")

uc_registered_model_info = mlflow.register_model(
    model_uri=logged_chain_info.model_uri, 
    name=f"{catalog}.{schema}.{model_name}"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Deploy Agent to Model Serving

# COMMAND ----------

#TODO: add wait until it's ready

# COMMAND ----------

uc_registered_model_info.version

# COMMAND ----------

from databricks import agents

deployed_agent = agents.deploy(
    model_name=uc_registered_model_info.name,
    model_version=uc_registered_model_info.version,
    environment_vars={
        "DATABRICKS_URL": os.environ["DATABRICKS_URL"],
        "DATABRICKS_TOKEN": os.environ["DATABRICKS_TOKEN"],
    },
    workload_size="Small",
    workload_type="CPU",
    scale_to_zero=True
)

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import ServingEndpointAccessControlRequest, ServingEndpointDetailedPermissionLevel

# COMMAND ----------

def set_endpoint_permissions(endpoint_id: str):
    w = WorkspaceClient()
    w.serving_endpoints.update_permissions(
        serving_endpoint_id=endpoint_id,
        access_control_list=[
            ServingEndpointAccessControlRequest(
                group_name="C-MIG-Databricks-IM-IMDX-Test-Operations",
                permission_level=ServingEndpointDetailedPermissionLevel.CAN_MANAGE,
            ),
            ServingEndpointAccessControlRequest(
                service_principal_name="ee2540d2-71df-43e9-8259-7b29a546f97e ",
                permission_level=ServingEndpointDetailedPermissionLevel.CAN_MANAGE,
            )]
        
    )


# COMMAND ----------

from mlflow.deployments import get_deploy_client
def get_endpoint_id(endpoint_name):
    EP_NAME = deployed_agent.endpoint_name
    client = get_deploy_client("databricks")
    endpoint = client.get_endpoint(endpoint=EP_NAME)
    return endpoint.id

# COMMAND ----------

set_endpoint_permissions(endpoint_id = get_endpoint_id(endpoint_name=deployed_agent.endpoint_name))

# COMMAND ----------

# from mlflow.deployments import get_deploy_client
# client = get_deploy_client("databricks")
# endpoint = client.get_endpoint(endpoint=EP_NAME)
# endpoint

# COMMAND ----------

# EPID = endpoint.id

# COMMAND ----------

# import requests
# cur = requests.get(f"{DATABRICKS_HOST}/api/2.0/permissions/serving-endpoints/{EPID}", headers={"Authorization": f"Bearer {DATABRICKS_TOKEN}"})
# cur.json()

# COMMAND ----------

# acl = cur.json()["access_control_list"]

# COMMAND ----------

# SPID = "ee2540d2-71df-43e9-8259-7b29a546f97e "

# COMMAND ----------

# entry = {"service_principal_name": SPID, "permission_level": "CAN_MANAGE"}

# if not any(e.get("service_principal_name" == SPID and e.get("permission_level") == "CAN_MANAGE") for e in acl):
#     acl.append(entry)

# COMMAND ----------

# requests.put(f"{DATABRICKS_HOST}/api/2.0/permissions/serving-endpoints/{EPID}", json={"access_control_list": acl}, headers={"Authorization": f"Bearer {DATABRICKS_TOKEN}"})

# COMMAND ----------

# agents.set_permissions(
#     serving_endpoint_id=deployed_agent.endpoint_name,
#     users="bea.yu@voya.com",
#     permission_level="CAN_MANAGE"
# )

# COMMAND ----------

# MAGIC %md
# MAGIC # SCRATCH BELOW
# MAGIC
# MAGIC - version 6: `models:/m-5da8e50f8ada4d138957312f519bbe07`
# MAGIC - version 7: `models:/m-1f01ed1c46fe4a4a9c455d0a7d0553db`

# COMMAND ----------

# # register version 6 as a separate model for now
# mlflow.set_registry_uri("databricks-uc")

# uc_registered_model_info = mlflow.register_model(
#     model_uri="models:/m-5da8e50f8ada4d138957312f519bbe07", # version 6
#     name=f"{catalog}.{schema}.{model_name}_testonly"
# )

# uc_registered_model_info

# COMMAND ----------

# from databricks import agents

# agents.deploy(
#     endpoint_name="agent_champ_test",
#     model_name=uc_registered_model_info.name,
#     model_version=uc_registered_model_info.version,
#     environment_vars={
#         "DATABRICKS_URL": os.environ["DATABRICKS_URL"],
#         "DATABRICKS_TOKEN": os.environ["DATABRICKS_TOKEN"],
#     },
#     workload_size="Small",
#     workload_type="CPU",
#     scale_to_zero=True
# )

# COMMAND ----------

