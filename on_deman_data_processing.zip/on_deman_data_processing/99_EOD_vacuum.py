# Databricks notebook source
# MAGIC %md
# MAGIC THIS NOTEBOOK WILL RUN EOD TO CLEAN UP THE ON DEMAND DATA

# COMMAND ----------

# MAGIC %md
# MAGIC ## Delete all the files in on_demand_volume

# COMMAND ----------

# reload
%reload_ext autoreload
%autoreload 2

# COMMAND ----------

# MAGIC %pip install databricks-vectorsearch
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

from config import DataProcessing_Config, VectorSearch_Config

data_config = DataProcessing_Config()
vs_config = VectorSearch_Config()

# COMMAND ----------

# Remove the directory and all its contents recursively
dbutils.fs.rm(
    data_config.on_demand_data_volume,
    recurse=True
)

# COMMAND ----------

# recreate the on_demand_volume folder
dbutils.fs.mkdirs(f"{data_config.on_demand_data_volume}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## reset VS Endpoint

# COMMAND ----------

# delete the source table
spark.sql(f"DELETE FROM {data_config.uc_catalog}.{data_config.uc_schema}.{data_config.aggregated_chunks_table} WHERE TRUE")

# delete the KIE table
spark.sql(f"DELETE FROM {data_config.uc_catalog}.{data_config.uc_schema}.{data_config.aggregated_info_extract_table} WHERE TRUE")

# COMMAND ----------

# delete the index table
from databricks.vector_search.client import VectorSearchClient
vs_client = VectorSearchClient()
vs_client.delete_index(endpoint_name=vs_config.vs_endpoint_name, index_name=f"{data_config.uc_catalog}.{data_config.uc_schema}.{data_config.aggregated_chunks_table}_index")