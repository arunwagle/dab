# Databricks notebook source
# MAGIC %md
# MAGIC ### Set up

# COMMAND ----------

# reload
%reload_ext autoreload
%autoreload 2

# COMMAND ----------

# MAGIC %pip install databricks-vectorsearch
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import time
from typing import List, Optional, Literal

from databricks.vector_search.client import VectorSearchClient
from databricks.sdk import WorkspaceClient

from config import LLM_Config, DataProcessing_Config, VectorSearch_Config


# COMMAND ----------

llm_config = LLM_Config()
data_config = DataProcessing_Config()
vs_config = VectorSearch_Config()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create vector search endpoint

# COMMAND ----------

# Initialize clients
vsc = VectorSearchClient()
wc = WorkspaceClient()

try:
    endpoints = vsc.list_endpoints()
    endpoint_exists = any(
        endpoint.get("name") == vs_config.vs_endpoint_name
        for endpoint in endpoints.get("endpoints", [])
    )
    if not endpoint_exists:
        print(f"Creating vector search endpoint: {vs_config.vs_endpoint_name}")
        vsc.create_endpoint(name=vs_config.vs_endpoint_name, endpoint_type=vs_config.vs_endpoint_type)
        # Wait for endpoint to be ready
        while True:
            endpoint_status = (
                vsc.get_endpoint(vs_config.vs_endpoint_name).get("endpoint_status", {}).get("state")
            )
            if endpoint_status == "ONLINE":
                print(f"Endpoint {vs_config.vs_endpoint_name} is online")
                break
            elif endpoint_status in ["FAILED", "DELETED"]:
                raise Exception(
                    f"Endpoint {vs_config.vs_endpoint_name} creation failed with state: {endpoint_status}"
                )
            print(
                f"Waiting for endpoint {vs_config.vs_endpoint_name} to be ready... "
                f"Current state: {endpoint_status}"
            )
            time.sleep(30)
    else:
        print(f"Endpoint {vs_config.vs_endpoint_name} already exists")
except Exception as e:
    raise Exception(f"Failed to create or verify endpoint {vs_config.vs_endpoint_name}: {str(e)}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create vector index

# COMMAND ----------

base_table_name=f"{data_config.uc_catalog}.{data_config.uc_schema}.{data_config.aggregated_chunks_table}"

try:
    indexes = vsc.list_indexes(vs_config.vs_endpoint_name).get("vector_indexes", [])
    index_exists = any(index.get("name") == base_table_name + "_index" for index in indexes)

    if not index_exists:
        index = vsc.create_delta_sync_index(
            endpoint_name=vs_config.vs_endpoint_name,
            index_name=base_table_name + "_index",
            source_table_name=base_table_name,
            primary_key="doc_id",
            pipeline_type="TRIGGERED",
            embedding_source_column="doc_chunk",
            embedding_model_endpoint_name=vs_config.embedding_endpoint_name,
        )
        print(f"Creating vector search index: {base_table_name}_index")
    else:
        index = vsc.get_index(vs_config.vs_endpoint_name, base_table_name + "_index")
        index.sync()
        print(f"Triggered sync for index: {base_table_name}_index")
except Exception as e:
        raise Exception(f"Failed to create index {base_table_name}_index: {str(e)}")

# COMMAND ----------

import time
while not index.describe().get("status").get("detailed_state").startswith("ONLINE"):
  print("Waiting for index to be ready...")
  time.sleep(30)
print("Index is ready")

# COMMAND ----------

dbutils.widgets.text("session_id", "")
session_id = dbutils.widgets.get("session_id")

# COMMAND ----------

status_table = "on_demand_processing_status_table"
import json
payload = {
    "job_id": "22822922431800",                              
    "session_id": session_id,
    "status": "ready to query",
}

# COMMAND ----------

dbutils.notebook.exit(json.dumps(payload))