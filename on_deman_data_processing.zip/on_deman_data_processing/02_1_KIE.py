# Databricks notebook source
# MAGIC %md
# MAGIC ## Set up

# COMMAND ----------

# reload
%reload_ext autoreload
%autoreload 2

# COMMAND ----------

import os
import uuid

from pyspark.sql.types import *
from pyspark.sql import functions as F

from config import LLM_Config, DataProcessing_Config, VectorSearch_Config

# COMMAND ----------

llm_config = LLM_Config()
data_config = DataProcessing_Config()
vs_config = VectorSearch_Config()

# COMMAND ----------

dbutils.widgets.text("session_id", "")
session_id = dbutils.widgets.get("session_id")
# session_id = dbutils.jobs.taskValues.get(taskKey="parsing", key="session_id", default="")

# COMMAND ----------

#input
parsed_pdfs = f"parsed_pdfs_{session_id}"

df_parsed = spark.read.table(f"{data_config.uc_catalog}.{data_config.uc_schema}.{parsed_pdfs}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Information Extraction

# COMMAND ----------

# DBTITLE 1,KIE schema
EVENT_SCHEMA = StructType([
    StructField("title", StringType(), False),
    StructField("date", StringType(), True),
    StructField("details", StringType(), True),
])

EXTRACTION_SCHEMA = StructType([
    StructField("file_name", StringType(), False),
    StructField("announced_date", StringType(), False),
    StructField("discipline", StringType(), False),
    StructField("broker_name", StringType(), False),
    StructField("summary", StringType(), False),
    StructField("ticker", StringType(), False),
    StructField("company_name", StringType(), False),
    StructField("sentiment", DoubleType(), False),
    StructField("major_events", ArrayType(EVENT_SCHEMA), False),
])


# COMMAND ----------

# MAGIC %md
# MAGIC #### Create extracted info table

# COMMAND ----------

# Create a "prompt" column with the full prompt
df_prompted = (
    df_parsed
    .withColumn(
        "prompt_new",
        F.concat(
            F.lit(llm_config.prompts["information_extraction_prompt"].strip()),
            F.lit("\n\nfile_name: "), F.col("file_name"),
            F.lit("\nfile_content: "), F.col("parsed_all")
        )
    )
)

# Call ai_query()
raw_df = df_prompted.withColumn(
    "raw_response",
    F.expr(
        f"""
        ai_query(
          '{llm_config.llm_name}',
          prompt_new,
          modelParameters => named_struct('max_tokens', {llm_config.max_tokens}, 'temperature', {llm_config.temperature})
        )
        """
    )
)


# COMMAND ----------

# UDF to generate UUID
uuid_udf = F.udf(lambda: str(uuid.uuid4()))
parsed_df = raw_df.withColumn("extracted", F.from_json("raw_response", EXTRACTION_SCHEMA))

# Add the new columns
result_df = parsed_df.select(
    F.col("extracted").alias("full_json"),
    F.col("extracted.file_name").alias("file_name"),
    F.col("extracted.announced_date").alias("announced_date"),
    F.col("extracted.broker_name").alias("broker_name"),
    F.col("extracted.discipline").alias("discipline"),
    F.col("extracted.summary").alias("summary"),
    F.col("extracted.ticker").alias("ticker"),
    F.col("extracted.company_name").alias("company_name"),
    F.col("extracted.sentiment").alias("sentiment"),
    F.col("extracted.major_events").alias("major_events"),
    F.when(F.col("announced_date") != "", F.year(F.col("announced_date"))).otherwise(None).cast("string").alias("calendar_year"),
    F.lit(None).cast("string").alias("fiscal_year"),
    F.lit(None).cast("string").alias("fiscal_quarter"),
    uuid_udf().alias("id"),
    F.lit(session_id).alias("session_id"),
    "parsed_all",
)


# COMMAND ----------

(result_df.write
 .mode("append")
 .option("overwriteSchema", "true")
 .format("delta")
 .saveAsTable(f"{data_config.uc_catalog}.{data_config.uc_schema}.{data_config.aggregated_info_extract_table}"))

# COMMAND ----------

