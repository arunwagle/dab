# Databricks notebook source
# MAGIC %md
# MAGIC ### Set up

# COMMAND ----------

# reload
%reload_ext autoreload
%autoreload 2

# COMMAND ----------

# MAGIC %pip install langchain-text-splitters
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import os

import pyspark.sql.functions as F
import pandas as pd
from pyspark.sql.types import *
from langchain_text_splitters import RecursiveCharacterTextSplitter

from config import LLM_Config, DataProcessing_Config, VectorSearch_Config


# COMMAND ----------

llm_config = LLM_Config()
data_config = DataProcessing_Config()
vs_config = VectorSearch_Config()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create vector table

# COMMAND ----------

dbutils.widgets.text("session_id", "")
session_id = dbutils.widgets.get("session_id")
# session_id = dbutils.jobs.taskValues.get(taskKey="parsing", key="session_id", default="")

# COMMAND ----------

# output locations
df = spark.read.table(f"{data_config.uc_catalog}.{data_config.uc_schema}.{data_config.aggregated_info_extract_table}")

#filter by session_id
df = df.filter(F.col("session_id") == session_id)

# COMMAND ----------

# df = spark.read.table(f"{data_config.uc_catalog}.{data_config.uc_schema}.{info_extract_table}")

# COMMAND ----------

splitter = RecursiveCharacterTextSplitter(
    chunk_size=5000,
    chunk_overlap=500,
    length_function=len,
    separators = ["\n\n", "\n", ". "],
    keep_separator = 'end'
)

return_schema = ArrayType(StructType([
    StructField("chunk_id", IntegerType()),
    StructField("chunk", StringType()),
]))
@F.pandas_udf(returnType = return_schema)
def split_to_structs(text_col: pd.Series) -> pd.Series:
    return text_col.apply(lambda x: [{"chunk_id": i, "chunk": chunk} for i, chunk in enumerate(splitter.split_text(x  or ""))])

chunked = (
    df
    .withColumn("chunks_struct", split_to_structs(F.col("parsed_all")))
    .selectExpr("* except(chunks_struct)", "explode(chunks_struct) as cs")
    .selectExpr("* except(cs)", "cs.chunk_id as chunk_id", "cs.chunk as doc_chunk")
    .withColumn("doc_id",  F.concat(F.col("id"), F.lit("-"), F.col("chunk_id")))
)


# COMMAND ----------

chunked = chunked.withColumn(
    "announced_date",
    F.date_format(
        F.to_date(F.col("announced_date"), "yyyy-MM-dd"),
        "yyyyMMdd"
    ).cast("int")
).withColumn(
    "doc_chunk",
    F.concat(
        F.col("broker_name"),
        F.lit(": "),
        F.col("file_name"),
        F.lit("\n\n"),
        F.col("doc_chunk")
    )
).select(
    "doc_id",
    F.col("id").alias("full_doc_id"),
    "broker_name",
    "discipline",
    "file_name",
    "announced_date",
    "calendar_year",
    "fiscal_year",
    "fiscal_quarter",
    "ticker",
    F.col("company_name").alias("name"),
    "chunk_id",
    "doc_chunk",
    "session_id"
)

# COMMAND ----------

(chunked.write
 .mode("append")
 .option("delta.enableChangeDataFeed", "true")
 .saveAsTable(f"{data_config.uc_catalog}.{data_config.uc_schema}.{data_config.aggregated_chunks_table}")
 )

# COMMAND ----------

# MAGIC %md
# MAGIC 1. append the new user data into base table
# MAGIC 2. trigger to update vs table