# Databricks notebook source
# MAGIC %md
# MAGIC ## Set up

# COMMAND ----------

# reload
%reload_ext autoreload
%autoreload 2

# COMMAND ----------

import uuid
import json
import os

import pandas as pd
from pyspark.sql import functions as F

from config import LLM_Config, DataProcessing_Config, VectorSearch_Config


# COMMAND ----------

llm_config = LLM_Config()
data_config = DataProcessing_Config()
vs_config = VectorSearch_Config()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Load and parse pdfs

# COMMAND ----------

# Front-end input
dbutils.widgets.text("session_id", "")
session_id = dbutils.widgets.get("session_id")

# COMMAND ----------

# DBTITLE 1,generate session_id
# import hashlib
# from datetime import datetime

# def generate_id(username:str) -> str:
#   curr_time = datetime.now()
#   username_curr_time = f"{username}_{curr_time}"
#   username_curr_time_hash = hashlib.md5(username_curr_time.encode()).hexdigest()
#   return username_curr_time_hash

# session_id = generate_id(user_name)

# on_demand output file
parsed_pdfs = f"parsed_pdfs_{session_id}"

# COMMAND ----------

pdf_folder_path = f"{data_config.on_demand_data_volume}/{session_id}"

# COMMAND ----------

# DBTITLE 1,ai_parse
df = spark.read.format("binaryFile") \
  .load(pdf_folder_path) \
  .withColumn(
    "parsed",
  F.expr("""
        ai_parse_document(
            content,
            map(
                'version', '2.0',
                'image_output_path', '/Volumes/imdx_test/ops_work/databricks_genai_poc/benchmark_test_pdfs/image_output/',
                'descriptionElementTypes', '*'
            )
        )
    """)
)


# COMMAND ----------

def extract_text(parsed_element):
  parsed_text  = ""
  for dic in parsed_element['document']['elements']:
    if dic['type'] in ['text', 'page_header', 'table', "caption"]:
      parsed_text = parsed_text + dic['content'] + "\n\n" 
    elif dic['type'] == "section_header":
      parsed_text = parsed_text + "##" + dic['content']  + "\n\n" 
    elif dic['type'] == "figure":
      parsed_text = parsed_text + dic['description'] + "\n\n"
  return parsed_text


pdf = df.toPandas()
pdf['parsed_json'] = pdf['parsed'].apply(lambda x: json.loads(str(x)))
pdf['parsed_all'] = pdf['parsed_json'].apply(lambda x: extract_text(x))
pdf['file_name'] = pdf['path'].apply(lambda x: os.path.basename(x))
pdf['session_id'] = session_id

# COMMAND ----------

selected_pdf = pdf[["modificationTime", "length", "parsed_all", "file_name", "session_id"]]

# COMMAND ----------

(spark.createDataFrame(selected_pdf).write
 .mode("overwrite")
 .option("mergeSchema", "true")
 .format("delta")
 .saveAsTable(f"{data_config.uc_catalog}.{data_config.uc_schema}.{parsed_pdfs}")
)

# COMMAND ----------

session_id

# COMMAND ----------

# dbutils.jobs.taskValues.set(key="session_id", value=session_id)

# COMMAND ----------

# MAGIC %md
# MAGIC output of **parsed dataframe** in a dynamic UC location