# Databricks notebook source
# MAGIC %md
# MAGIC THIS NOTEBOOK WILL CLEAN UP THE UPLOAD PDFS AFTER UPDATING THE VS ENDPOINT

# COMMAND ----------

from config import DataProcessing_Config

data_config = DataProcessing_Config()

# COMMAND ----------

dbutils.widgets.text("session_id", "")
session_id = dbutils.widgets.get("session_id")
# session_id = dbutils.jobs.taskValues.get(taskKey="parsing", key="session_id", default="")

# COMMAND ----------

# MAGIC %md
# MAGIC Drop on-demand parsed_pdfs table

# COMMAND ----------

parsed_pdfs = f"parsed_pdfs_{session_id}"

# COMMAND ----------

# drop tables
spark.sql(f"DROP TABLE IF EXISTS {data_config.uc_catalog}.{data_config.uc_schema}.{parsed_pdfs}")

# COMMAND ----------

# MAGIC %md
# MAGIC clean up the on-demand folder

# COMMAND ----------

pdf_folder_path = f"{data_config.on_demand_data_volume}/{session_id}"

# COMMAND ----------

# Remove the directory and all its contents recursively
dbutils.fs.rm(
    pdf_folder_path,
    recurse=True
)