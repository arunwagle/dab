# import os
# import json
from typing import List, Optional, Literal, ClassVar

# import mlflow
# from databricks.sdk import WorkspaceClient
# from mlflow.entities import SpanType
# from mlflow.pyfunc import ResponsesAgent
from pydantic import BaseModel, Field, ValidationError

# from openai import OpenAI

# from pyspark.sql import functions as F
# from pyspark.sql.types import *

INFORMATION_EXTRACTION_PROMPT = """
You are a precise financial document analyst.
Return ONLY valid JSON. Do not include the word "json", code fences, or commentary. Please use the following schema:
{
  "file_name": str,
  "announced_date": str,
  "discipline": str,
  "broker_name": str,
  "summary": str,
  "ticker": str,
  "company_name": str,
  "sentiment": float,
  "major_events": [ {"title": str, "date": str|omit, "details": str|omit}, ... ]
}
Rules:
- sentiment ∈ [-1,1] (negative=bearish, positive=bullish)
- announced_date is the date the report was published
- discipline is the type of report (one of the 'Investment', 'Stategy', or 'Economics'). Any report that is related to equities is 'Investment'. Any report that is related to Macro is 'Economics'. Any report that is related to industry or asset allocations is 'Strategy'.
- broker_name is the name of the broker who wrote the report
- ticker uppercase, no duplicates
- company_name: the name of the company mentioned in the report (e.g., 'Amneal Pharmaceuticals Inc.,Teva Pharmaceutical Industries Limited'). Put them in a string split by commas.
- summary = 5-10 objective sentences. please include as much numbers and details as you can.
- include only material events
- Do not include any commentary or Markdown, JSON only.
"""

COMPARISON_PROMPT = """
    You are an equity-research evaluator. Based ONLY on the given summary text, decide which company has the strongest BUY signal.
    Instructions:
    - Identify the single best BUY candidate.
    - Return STRICT JSON with this schema (no code fences, no commentary):
    {
    "best_stock": string,        // file_name of the strongest BUY signal
    "stance": string,           // Strong Buy | Buy | Neutral | Sell | Strong Sell
    "rationale": string         // concise reason why this one is best
    }
    """
SUPERVISOR_PROMPT = """You are a routing supervisor for investment management questions. Read the user question and choose ONE agent type and any tools needed. only choose from these agnet types: somparison_agent, qa_agent, on_demand_qa_agent. 
Return ONLY valid JSON. 

Routing guidance:
- if the user asks to compare multiple documents/complies or rank strongest signals, use the comparison_agent.
- if the user asks a question about a factual question about content, use the qa_agent.
- if the user asks a question about a factual question about the documents they just uploaded, use the on_demand_qa_agent.
"""


class DataProcessing_Config(BaseModel):
    on_demand_data_volume: str = Field(default="/Volumes/imdx_test/ops_work/databricks_genai_poc/on_demand_volume/")
    # /Volumes/imdx_test/ops_work/databricks_genai_poc/benchmark_test_pdfs/
    uc_catalog: str = Field(default="imdx_test")
    uc_schema: str = Field("rag_poc")
    aggregated_chunks_table: str = Field("aggregated_chunks_table")
    aggregated_info_extract_table: str = Field("aggregated_info_extract_table")

class LLM_Config(BaseModel):
    llm_name: str = Field(default="databricks-claude-sonnet-4")
    temperature: float = Field(default=0.0)
    max_tokens: int = Field(default=1000)
    prompts: ClassVar[dict] = {
        "information_extraction_prompt": INFORMATION_EXTRACTION_PROMPT,
        "comparison_prompt": COMPARISON_PROMPT,
        "supervisor_prompt": SUPERVISOR_PROMPT,
    }
    llm_serving_url: str = Field(default="https://adb-885874152858784.4.azuredatabricks.net/serving-endpoints")

class VectorSearch_Config(BaseModel):
    vs_endpoint_name: str = Field("voya_rag_poc")
    vs_endpoint_type: str = Field("STANDARD")
    embedding_endpoint_name: str = Field("gte-large-pt")


